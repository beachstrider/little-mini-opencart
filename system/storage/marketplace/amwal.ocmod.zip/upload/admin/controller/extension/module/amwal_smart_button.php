<?php

class ControllerExtensionModuleAmwalSmartButton extends Controller
{
	private $error = [];

	public function index(): void
	{
		$this->load->language('extension/payment/amwal');

		$this->load->model('extension/payment/amwal');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extensions'),
			'href' => $this->url->link('marketplace/opencart/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/amwal', 'user_token=' . $this->session->data['user_token'])
		];

		$data['save'] = $this->url->link('extension/payment/amwal|save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

		$data['partner_url'] = str_replace('&amp;', '%26', $this->url->link('extension/payment/amwal', 'user_token=' . $this->session->data['user_token']));
		$data['callback_url'] = str_replace('&amp;', '&', $this->url->link('extension/payment/amwal|callback', 'user_token=' . $this->session->data['user_token']));
		$data['disconnect_url'] = str_replace('&amp;', '&', $this->url->link('extension/payment/amwal|disconnect', 'user_token=' . $this->session->data['user_token']));
		$data['configure_smart_button_url'] = $this->url->link('extension/payment/amwal|configureSmartButton', 'user_token=' . $this->session->data['user_token']);

		$data['server'] = HTTP_SERVER;
		$data['catalog'] = HTTP_CATALOG;

		// Setting
		$_config = new Config();
		$_config->load('amwal');

		$data['setting'] = $_config->get('amwal_setting');

		if ($this->config->get('payment_amwal_api_key')) {
			$data['amwal_api_key_value'] = $this->config->get('payment_amwal_api_key');
		}

		if ($this->config->get('payment_amwal_currency_code')) {
			$data['payment_amwal_currency_code'] = $this->config->get('payment_amwal_currency_code');
		}

		if ($this->config->get('payment_amwal_dark_mode_value')) {
			$data['amwal_dark_mode_value'] = $this->config->get('payment_amwal_dark_mode_value');
		}

		if ($this->config->get('payment_amwal_address_required')) {
			$data['amwal_address_required_value'] = $this->config->get('payment_amwal_address_required');
		}

		if ($this->config->get('payment_amwal_guest_email_required')) {
			$data['amwal_guest_email_required_value'] = $this->config->get('payment_amwal_guest_email_required');
		}

		if ($this->config->get('payment_amwal_test_mode')) {
			$data['amwal_test_mode_value'] = $this->config->get('payment_amwal_test_mode');
		}

		if ($this->config->get('payment_amwal_debug_mode')) {
			$data['amwal_debug_mode_value'] = $this->config->get('payment_amwal_debug_mode');
		}

		if ($this->config->get('payment_amwal_button_in_product_page')) {
			$data['amwal_button_in_product_page_value'] = $this->config->get('payment_amwal_button_in_product_page');
		}

		if ($this->config->get('payment_amwal_hide_button_if_cart_has_item')) {
			$data['amwal_hide_button_if_cart_has_item_value'] = $this->config->get('payment_amwal_hide_button_if_cart_has_item');
		}

		if ($this->config->get('payment_amwal_automaticaly_render_in_cart_page')) {
			$data['amwal_automaticaly_render_in_cart_page_value'] = $this->config->get('payment_amwal_automaticaly_render_in_cart_page');
		}

		if ($this->config->get('payment_amwal_automaticaly_render_in_mini_cart')) {
			$data['amwal_automaticaly_render_in_mini_cart_value'] = $this->config->get('payment_amwal_automaticaly_render_in_mini_cart');
		}

		if (isset($data['amwal_api_key_value'])) {
			$amwal_info = [
				'payment_amwal_api_key' => $data['amwal_api_key_value'],
				'payment_amwal_currency_code' => $data['payment_amwal_currency_code'],
				'payment_amwal_dark_mode_value' => array_key_exists('amwal_dark_mode_value', $data) ? true : false,
				'payment_amwal_address_required' => array_key_exists('amwal_address_required_value', $data) ? true : false,
				'payment_amwal_guest_email_required' => array_key_exists('amwal_guest_email_required_value', $data) ? true : false,
				'payment_amwal_test_mode' => array_key_exists('amwal_test_mode_value', $data) ? true : false,
				'payment_amwal_debug_mode' => array_key_exists('amwal_debug_mode_value', $data) ? true : false,
				'payment_amwal_button_in_product_page' => array_key_exists('amwal_button_in_product_page_value', $data) ? true : false,
				'payment_amwal_hide_button_if_cart_has_item' => array_key_exists('amwal_hide_button_if_cart_has_item_value', $data) ? true : false,
				'payment_amwal_automaticaly_render_in_cart_page' => array_key_exists('amwal_automaticaly_render_in_cart_page_value', $data) ? true : false,
				'payment_amwal_automaticaly_render_in_mini_cart' => array_key_exists('amwal_automaticaly_render_in_mini_cart_value', $data) ? true : false
			];
			require_once DIR_SYSTEM . 'library/amwal/amwal.php';

			$amwal = new Amwal($amwal_info);
			if ($amwal_info['payment_amwal_api_key']) {
				$amwal->verifyMerchantAPIKey($amwal_info['payment_amwal_api_key']);
			}
			if (!$amwal->hasErrors()) {
				$data['status'] = true;
			} else {
				$data['status'] = false;
			}
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/amwal', $data));
	}

	public function save(): void
	{
		$this->load->language('extension/module/amwal_smart_button');

		$this->load->model('extension/module/amwal_smart_button');

		if (!$this->user->hasPermission('modify', 'extension/module/amwal_smart_button')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->error) {
			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('module_amwal_smart_button', $this->request->post);

			$data['success'] = $this->language->get('success_save');
		}

		$data['error'] = $this->error;

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));
	}

	public function install(): void
	{
		$this->load->model('extension/module/amwal_smart_button');
		$this->load->model('setting/setting');

		$this->model_extension_module_amwal_smart_button->install();

		$setting['module_amwal_smart_button_status'] = 0;

		$this->model_setting_setting->editSetting('module_amwal_smart_button', $setting);
	}
}