<?php
// Heading
$_['amwal_basic_configuration'] = 'إعدادات';
$_['amwal_button_configuration'] = 'اعدادت الزر';
$_['amwal_button_styling_configuration'] = 'Advanced Styling';
$_['amwal_api_key'] = 'Amwal API Key';
$_['amwal_dark_mode'] = 'مظهر داكن';
$_['amwal_dark_mode_label'] = 'تفعيل الوضع الداكن لأزرار أموال.';
$_['help_dark_mode'] = 'عند تحديد هذا المربع ، سيتم عرض أزرار أموال في الوضع المظلم.';

$_['amwal_address_required'] = 'العنوان مطلوب';
$_['amwal_address_required_label'] = 'تمكين الخيار المطلوب العنوان.';
$_['help_address_required'] = 'عند تفعيل خيار العنوان المطلوب ، سيعيد Amwal Checkout Plugin العنوان.';

$_['amwal_guest_email_required'] = 'البريد الإلكتروني للضيف مطلوب';
$_['amwal_guest_email_required_label'] = 'تمكين الخيار المطلوب البريد الإلكتروني الضيف.';
$_['help_guest_email_required'] = 'عند تفعيل خيار العنوان المطلوب ، سيرسل برنامج Amwal Checkout Plugin رسالة بريد إلكتروني لتأكيد الطلب إلى الضيف.';

$_['amwal_test_mode'] = 'وضع الاختبار';
$_['amwal_test_mode_label'] = 'تفعيل وضع الاختبار.';
$_['help_test_mode'] = 'عندما يتم تمكين وضع الاختبار ، فقط المستخدمون المسؤولون الذين قاموا بتسجيل الدخول سيرون زر Amwal Checkout.';


$_['amwal_debug_mode'] = 'وضع التصحيح';
$_['amwal_debug_mode_label'] = 'تفعيل وضع التصحيح.';
$_['help_debug_mode'] = 'عند تفعيل وضع التصحيح ، سيحتفظ البرنامج المساعد لأموال بسجل خطأ.';

$_['amwal_button_in_product_page'] = 'عرض زر أموال تلقائيًا في صفحة المنتج';
$_['amwal_button_in_product_page_label'] = 'عرض زر أموال تلقائيًا في صفحات المنتج.';

$_['amwal_hide_button_if_cart_has_item'] = 'إخفاء الزر إذا كانت العربة تحتوي على عنصر واحد على الأقل';
$_['amwal_hide_button_if_cart_has_item_label'] = 'إخفاء زر أموال إذا كانت سلة التسوق تحتوي على عنصر واحد على الأقل.';

$_['amwal_automaticaly_render_in_cart_page'] = 'عرض زر أموال تلقائيًا في صفحة عربة التسوق';
$_['amwal_automaticaly_render_in_cart_page_label'] = 'عرض زر أموال تلقائيا في صفحة سلة التسوق.';

$_['amwal_automaticaly_render_in_mini_cart'] = 'Render quick checkout in minicart widget';
$_['amwal_automaticaly_render_in_mini_cart_label'] = 'Render quick checkout in minicart widget.';

$_['column_order_id'] = 'رقم التسلسلي لأموال';
$_['heading_title'] = 'Amwal Checkout Button';

// Text
$_['text_extensions'] = 'Extensions';
$_['text_edit'] = 'Edit Amwal';

$_['text_checkout_card'] = 'Advanced Card';
$_['text_checkout_message'] = 'Pay Later Message';
$_['text_production'] = 'Production';
$_['text_sandbox'] = 'Sandbox';
$_['text_authorization'] = 'Authorization';
$_['text_sale'] = 'Sale';
$_['text_connect'] = 'Your seller account has been connected.<br />Client ID = %s<br />Secret = %s<br />Merchant ID = %s<br />If you would like to connect another account, please, disconnect.';
$_['text_message'] = 'Display pay later messaging on your site for offers like Pay in 3, which lets customers pay with 3 interest-free monthly payments. We\'ll show messages on your site to promote this feature for you. You may not promote pay later offers with any other content, marketing, or materials.';
$_['text_currency_aud'] = 'Australian Dollar';
$_['text_currency_brl'] = 'Brazilian Real';
$_['text_currency_cad'] = 'Canadian Dollar';
$_['text_currency_czk'] = 'Czech Krone';
$_['text_currency_dkk'] = 'Danish Krone';
$_['text_currency_eur'] = 'Euro';
$_['text_currency_hkd'] = 'Hong Kong Dollar';
$_['text_currency_huf'] = 'Hungarian Forint';
$_['text_currency_inr'] = 'Indian Rupee';
$_['text_currency_ils'] = 'Israeli New Shekel';
$_['text_currency_jpy'] = 'Japanese Yen';
$_['text_currency_myr'] = 'Malaysian Ringgit';
$_['text_currency_mxn'] = 'Mexican Peso';
$_['text_currency_twd'] = 'New Taiwan Dollar';
$_['text_currency_nzd'] = 'New Zealand Dollar';
$_['text_currency_nok'] = 'Norwegian Krone';
$_['text_currency_php'] = 'Philippine peso';
$_['text_currency_pln'] = 'Polish Zloty';
$_['text_currency_gbp'] = 'Pound Sterling';
$_['text_currency_rub'] = 'Russian Ruble';
$_['text_currency_sgd'] = 'Singapore Dollar';
$_['text_currency_sek'] = 'Swedish Krone';
$_['text_currency_chf'] = 'Swiss Frank';
$_['text_currency_thb'] = 'Thai Baht';
$_['text_currency_usd'] = 'US Dollar';
$_['text_currency_sar'] = 'Saudi Riyal';
$_['text_completed_status'] = 'Completed Status';
$_['text_denied_status'] = 'Denied Status';
$_['text_failed_status'] = 'Failed Status';
$_['text_pending_status'] = 'Pending Status';
$_['text_processing_status'] = 'Processing Status';
$_['text_refunded_status'] = 'Refunded Status';
$_['text_reversed_status'] = 'Reversed Status';
$_['text_voided_status'] = 'Voided Status';
$_['text_align_left'] = 'Align Left';
$_['text_align_center'] = 'Align Center';
$_['text_align_right'] = 'Align Right';
$_['text_small'] = 'Small';
$_['text_medium'] = 'Medium';
$_['text_large'] = 'Large';
$_['text_responsive'] = 'Responsive';
$_['text_gold'] = 'Gold';
$_['text_blue'] = 'Blue';
$_['text_silver'] = 'Silver';
$_['text_white'] = 'White';
$_['text_black'] = 'Black';
$_['text_pill'] = 'Pill';
$_['text_rect'] = 'Rect';
$_['text_checkout'] = 'Checkout';
$_['text_pay'] = 'Pay';
$_['text_buy_now'] = 'Buy Now';
$_['text_pay_pal'] = 'Amwal';
$_['text_installment'] = 'Installment';
$_['text_card'] = 'Credit or debit cards';
$_['text_credit'] = 'Amwal Credit';
$_['text_bancontact'] = 'Bancontact';
$_['text_blik'] = 'BLIK';
$_['text_eps'] = 'Eps';
$_['text_giropay'] = 'Giropay';
$_['text_ideal'] = 'iDEAL';
$_['text_mercadopago'] = 'Mercado Pago';
$_['text_mybank'] = 'MyBank';
$_['text_p24'] = 'Przelewy24';
$_['text_sepa'] = 'SEPA-Lastschrift';
$_['text_sofort'] = 'Sofort';
$_['text_venmo'] = 'Venmo';
$_['text_paylater'] = 'Pay Later';
$_['text_auto'] = 'Auto';
$_['text_text'] = 'Text Message';
$_['text_flex'] = 'Flexible Banner';
$_['text_accept'] = 'Accept';
$_['text_decline'] = 'Decline';
$_['text_recommended'] = '(recommended)';
$_['text_3ds_failed_authentication'] = 'Failed authentication.';
$_['text_3ds_rejected_authentication'] = 'Rejected authentication.';
$_['text_3ds_attempted_authentication'] = 'Attempted authentication.';
$_['text_3ds_unable_authentication'] = 'Unable to complete authentication.';
$_['text_3ds_challenge_authentication'] = 'Challenge required for authentication.';
$_['text_3ds_card_ineligible'] = 'Card type and issuing bank are not ready to complete a 3D Secure authentication.';
$_['text_3ds_system_unavailable'] = 'System is unavailable at the time of the request.';
$_['text_3ds_system_bypassed'] = 'System has bypassed authentication.';
$_['text_confirm'] = 'Are you sure?';

// Entry
$_['entry_connect'] = 'Connect';
$_['entry_checkout_express_status'] = 'Checkout';
$_['entry_checkout_card_status'] = 'Advanced Card';
$_['entry_checkout_message_status'] = 'Pay Later Message';
$_['entry_debug'] = 'Debug Logging';
$_['entry_transaction_method'] = 'Settlement Method';
$_['entry_geo_zone'] = 'Geo Zone';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['entry_currency_code'] = 'العملة';
$_['entry_currency_value'] = 'Currency Value';
$_['entry_card_currency_code'] = 'Card Currency';
$_['entry_card_currency_value'] = 'Card Currency Value';
$_['entry_smart_button'] = 'Smart Button';
$_['entry_button_align'] = 'Button Align';
$_['entry_button_size'] = 'Button Size';
$_['entry_button_color'] = 'Button Color';
$_['entry_button_shape'] = 'Button Shape';
$_['entry_button_label'] = 'Button Label';
$_['entry_form_align'] = 'Form Align';
$_['entry_form_size'] = 'Form Size';
$_['entry_secure_status'] = '3D Secure Status';
$_['entry_secure_scenario'] = '3D Secure Scenarios';
$_['entry_message_align'] = 'Message Align';
$_['entry_message_size'] = 'Message Size';
$_['entry_message_layout'] = 'Message Layout';
$_['entry_message_text_color'] = 'Message Text Color';
$_['entry_message_text_size'] = 'Message Text Size';
$_['entry_message_flex_color'] = 'Message Banner Color';
$_['entry_message_flex_ratio'] = 'Message Banner Ratio';

// Help
$_['help_checkout_express'] = 'If your country is not available in the list when going through the Amwal onboarding experience please <a id="button_connect_express_checkout" href="%s" target="_blank" data-amwal-button="PPLtBlue" data-amwal-onboard-complete="onBoardedCallback">click here</a>.';
$_['help_checkout_express_status'] = 'When activated Amwal will display personalized Smart Buttons avalible to your customers based on their location.';
$_['help_checkout_card_status'] = 'Amwal verifies if you are eligible for advanced card payment and will display this option on the checkout step if available.';
$_['help_checkout_message_status'] = 'Add pay later messaging to your site.';
$_['help_currency_code'] = 'حدد العملة لأموال.';
$_['help_currency_value'] = 'Set to 1.00000 if this is your default currency.';
$_['help_card_currency_code'] = 'Select the default currency for Amwal Card.';
$_['help_card_currency_value'] = 'Set to 1.00000 if this is your default currency.';
$_['help_secure_status'] = '3D Secure enables you to authenticate card holders through card issuers. It reduces the likelihood of fraud when you use supported cards and improves transaction perfomance. A successful 3D Secure authentication can shift liability for chargebacks due to fraud from you -the merchant- to the card issuer.';
$_['help_secure_scenario'] = '3D Secure authentication is perfomed only if the card is enrolled for the service. In scenarios where the 3D Secure authentication has not been successful, you have the option to complete the payment at your own risk, meaning that you -the merchant- will be liable in case of a chargeback.';

// Button
$_['button_connect'] = 'Connect with Amwal';
$_['button_disconnect'] = 'Disconnect';
$_['button_smart_button'] = 'Smart Button Configure';

// Success
$_['success_save'] = 'Success: You have modified Amwal!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify payment Amwal!';
$_['error_timeout'] = 'Sorry, Amwal is currently busy. Please try again later!';