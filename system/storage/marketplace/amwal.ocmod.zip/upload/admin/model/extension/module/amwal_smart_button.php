<?php


class ModelExtensionModuleAmwalSmartButton extends Model
{

	public function install(): void
	{
		$query = $this->db->query("SELECT DISTINCT layout_id FROM " . DB_PREFIX . "layout_route WHERE route = 'product/product' OR route LIKE 'checkout/%'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "layout_module WHERE code = 'amwal_smart_button'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "layout_module WHERE code = 'amwal.amwal_smart_button'");
		$layouts = $query->rows;

		foreach ($layouts as $layout) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "layout_module SET layout_id = '" . (int) $layout['layout_id'] . "', code = 'amwal_smart_button', position = 'content_top', sort_order = '0'");
		}
	}
}