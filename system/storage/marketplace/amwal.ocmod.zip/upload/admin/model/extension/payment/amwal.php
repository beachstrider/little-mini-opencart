<?php

class ModelExtensionPaymentAmwal extends Model
{

	public function configureSmartButton(): void
	{
		$this->load->model('user/user_group');

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension WHERE `code` = 'amwal_smart_button' and `type` = 'module'");

		if (empty($query->row)) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "extension SET `type` = 'module', `code` = 'amwal_smart_button'");

			$user_group_id = $this->user->getGroupId();

			$this->model_user_user_group->addPermission($user_group_id, 'access', 'extension/payment/amwal');
			$this->model_user_user_group->addPermission($user_group_id, 'modify', 'extension/payment/amwal');
			$this->model_user_user_group->addPermission($user_group_id, 'access', 'extension/module/amwal_smart_button');
			$this->model_user_user_group->addPermission($user_group_id, 'modify', 'extension/module/amwal_smart_button');

		}
	}

	public function log(array $data = [], string $title = ''): void
	{
		if ($this->config->get('payment_amwal_debug')) {
			$log = new Log('amwal.log');
			$log->write('Amwal debug (' . $title . '): ' . json_encode($data));
		}
	}


	public function getOrder(int $order_id): array {
		$order_query = $this->db->query("SELECT *, (SELECT os.`name` FROM `" . DB_PREFIX . "order_status` os WHERE os.`order_status_id` = o.`order_status_id` AND os.`language_id` = o.`language_id`) AS order_status FROM `" . DB_PREFIX . "order` o WHERE o.`order_id` = '" . (int)$order_id . "'");

		if ($order_query->num_rows) {
			$order_data = $order_query->row;

			$this->load->model('localisation/country');
			$this->load->model('localisation/zone');

			$order_data['custom_field'] = json_decode($order_query->row['custom_field'], true);

			foreach (['payment', 'shipping'] as $column) {
				$country_info = $this->model_localisation_country->getCountry($order_query->row[$column . '_country_id']);

				if ($country_info) {
					$order_data[$column . '_iso_code_2'] = $country_info['iso_code_2'];
					$order_data[$column . '_iso_code_3'] = $country_info['iso_code_3'];
				} else {
					$order_data[$column . '_iso_code_2'] = '';
					$order_data[$column . '_iso_code_3'] = '';
				}

				$zone_info = $this->model_localisation_zone->getZone($order_query->row[$column . '_zone_id']);

				if ($zone_info) {
					$order_data[$column . '_zone_code'] = $zone_info['code'];
				} else {
					$order_data[$column . '_zone_code'] = '';
				}

				$order_data[$column . '_custom_field'] = json_decode($order_query->row[$column . '_custom_field'], true);
			}
			return $order_data;
		}

		return [];
	}
}