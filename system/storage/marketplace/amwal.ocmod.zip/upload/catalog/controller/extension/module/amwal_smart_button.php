<?php

class ControllerExtensionModuleAmwalSmartButton extends Controller
{
	private $error = [];



	public function index(): string
	{
		if ($this->config->get('payment_amwal_api_key') && $this->config->get('payment_amwal_currency_code')) {
			$status = false;

			// Setting
			$_config = new Config();
			$_config->load('amwal');

			$amwal_setting = $_config->get('amwal_setting');

			$_config = new Config();
			$_config->load('amwal_smart_button');

			$config_setting = $_config->get('amwal_smart_button_setting');

			$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('module_amwal_smart_button_setting'));

			$currency_code = $this->session->data['currency'];
			$currency_value = $this->currency->getValue($this->session->data['currency']);

			if (empty($amwal_setting['currency'][$currency_code]['express_status'])) {
				$currency_code = $this->config->get('payment_amwal_currency_code');
				$currency_value = $this->config->get('payment_amwal_currency_value');
			}

			$decimal_place = $amwal_setting['currency'][$currency_code]['decimal_place'];

			if ($setting['page']['product']['status'] && ($this->request->get['route'] == 'product/product') && isset($this->request->get['product_id']) && $this->config->get('payment_amwal_button_in_product_page') && (($this->config->get('payment_amwal_hide_button_if_cart_has_item') && !$this->cart->getTotal()) || !$this->config->get('payment_amwal_hide_button_if_cart_has_item'))) {
				$data['insert_tag'] = html_entity_decode($setting['page']['product']['insert_tag']);
				$data['insert_type'] = $setting['page']['product']['insert_type'];
				$data['button_align'] = $setting['page']['product']['button_align'];
				$data['button_size'] = $setting['page']['product']['button_size'];
				$data['button_color'] = $setting['page']['product']['button_color'];
				$data['button_shape'] = $setting['page']['product']['button_shape'];
				$data['button_label'] = $setting['page']['product']['button_label'];
				$data['button_tagline'] = $setting['page']['product']['button_tagline'];

				$data['button_enable_funding'] = [];
				$data['button_disable_funding'] = [];
				$data['position'] = 'product';
				foreach ($setting['button_funding'] as $button_funding) {
					if ($setting['page']['product']['button_funding'][$button_funding['code']] == 1) {
						$data['button_enable_funding'][] = $button_funding['code'];
					}

					if ($setting['page']['product']['button_funding'][$button_funding['code']] == 2) {
						$data['button_disable_funding'][] = $button_funding['code'];
					}
				}

				$data['message_status'] = $setting['page']['product']['message_status'];
				$data['message_align'] = $setting['page']['product']['message_align'];
				$data['message_size'] = $setting['page']['product']['message_size'];
				$data['message_layout'] = $setting['page']['product']['message_layout'];
				$data['message_text_color'] = $setting['page']['product']['message_text_color'];
				$data['message_text_size'] = $setting['page']['product']['message_text_size'];
				$data['message_flex_color'] = $setting['page']['product']['message_flex_color'];
				$data['message_flex_ratio'] = $setting['page']['product']['message_flex_ratio'];
				$data['message_placement'] = 'product';

				$product_id = (int) $this->request->get['product_id'];

				$this->load->model('catalog/product');

				$product_info = $this->model_catalog_product->getProduct($product_id);

				if ($product_info) {
					if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
						if ((float) $product_info['special']) {
							$product_price = $this->tax->calculate($product_info['special'], $product_info['tax_class_id'], true);
						} else {
							$product_price = $this->tax->calculate($product_info['price'], $product_info['tax_class_id'], true);
						}

						$data['message_amount'] = number_format($product_price * $currency_value, $decimal_place, '.', '');
					}
				}
				$status = true;

			}

			if ($setting['page']['cart']['status'] && ($this->request->get['route'] == 'checkout/cart') && $this->cart->getTotal() && $this->config->get('payment_amwal_automaticaly_render_in_cart_page')) {
				$data['insert_tag'] = html_entity_decode($setting['page']['cart']['insert_tag']);
				$data['insert_type'] = $setting['page']['cart']['insert_type'];
				$data['button_align'] = $setting['page']['cart']['button_align'];
				$data['button_size'] = $setting['page']['cart']['button_size'];
				$data['button_color'] = $setting['page']['cart']['button_color'];
				$data['button_shape'] = $setting['page']['cart']['button_shape'];
				$data['button_label'] = $setting['page']['cart']['button_label'];
				$data['button_tagline'] = $setting['page']['cart']['button_tagline'];
				$data['position'] = 'cart';

				$data['button_enable_funding'] = [];
				$data['button_disable_funding'] = [];

				foreach ($setting['button_funding'] as $button_funding) {
					if ($setting['page']['cart']['button_funding'][$button_funding['code']] == 1) {
						$data['button_enable_funding'][] = $button_funding['code'];
					}

					if ($setting['page']['cart']['button_funding'][$button_funding['code']] == 2) {
						$data['button_disable_funding'][] = $button_funding['code'];
					}
				}

				$data['message_status'] = $setting['page']['cart']['message_status'];
				$data['message_align'] = $setting['page']['cart']['message_align'];
				$data['message_size'] = $setting['page']['cart']['message_size'];
				$data['message_layout'] = $setting['page']['cart']['message_layout'];
				$data['message_text_color'] = $setting['page']['cart']['message_text_color'];
				$data['message_text_size'] = $setting['page']['cart']['message_text_size'];
				$data['message_flex_color'] = $setting['page']['cart']['message_flex_color'];
				$data['message_flex_ratio'] = $setting['page']['cart']['message_flex_ratio'];
				$data['message_placement'] = 'cart';
				$item_total = 0;

				foreach ($this->cart->getProducts() as $product) {
					$product_price = $this->tax->calculate($product['price'], $product['tax_class_id'], true);

					$item_total += $product_price * $product['quantity'];
				}

				$data['message_amount'] = number_format($item_total * $currency_value, $decimal_place, '.', '');

				$status = true;
			}

			if ($status) {
				$this->load->model('localisation/country');
				$this->load->model('localisation/zone');

				$country = $this->model_localisation_country->getCountry($this->config->get('config_country_id'));

				$data['amwal_api_key_value'] = $this->config->get('payment_amwal_api_key');
				$data['payment_amwal_currency_code'] = $this->config->get('payment_amwal_currency_code');
				$data['amwal_dark_mode_value'] = $this->config->get('payment_amwal_dark_mode_value');
				if ($this->cart->hasShipping()) {
					$data['amwal_address_required_value'] = $this->config->get('payment_amwal_address_required');
				}
				$data['amwal_guest_email_required_value'] = $this->config->get('payment_amwal_guest_email_required');
				$data['amwal_test_mode_value'] = $this->config->get('payment_amwal_test_mode');
				$data['amwal_debug_mode_value'] = $this->config->get('payment_amwal_debug_mode');
				$data['amwal_button_in_product_page_value'] = $this->config->get('payment_amwal_button_in_product_page');
				$data['amwal_hide_button_if_cart_has_item_value'] = $this->config->get('payment_amwal_hide_button_if_cart_has_item');
				$data['amwal_automaticaly_render_in_cart_page_value'] = $this->config->get('payment_amwal_automaticaly_render_in_cart_page');
				$data['amwal_automaticaly_render_in_mini_cart_value'] = $this->config->get('payment_amwal_automaticaly_render_in_mini_cart');
				if (isset($this->session->data['customer_id'])) {
					$this->load->model('account/address');
					$addresses = $this->model_account_address->getAddresses();
					foreach ($addresses as $address) {
						$data['initialAddress'] = [
							'street1' => $address['address_1'],
							'street2' => $address['address_2'],
							'city' => $address['city'],
							'state' => $address['zone'],
							'postcode' => $address['postcode'],
							'country' => $address['iso_code_2'],
						];
						break;
					}
					if (isset($data['initialAddress'])) {
						$data['initialAddress'] = json_encode($data['initialAddress']);
					}

					if (isset($this->session->data['customer']) || $this->customer->getEmail()) {
						$data['initialEmail'] = isset($this->session->data['customer']) ? $this->session->data['customer']['email'] : $this->customer->getEmail();
					}
					if (isset($this->session->data['customer']['telephone']) || $this->customer->getTelephone()) {
						$data['initialPhoneNumber'] = isset($this->session->data['customer']['telephone']) ? $this->session->data['customer']['telephone'] : $this->customer->getTelephone();
					}
				}
				$data['currency_code'] = $this->session->data['currency'];
				$allowedCountries = $this->model_localisation_country->getCountries();
				$data['allowedAddressCountries'] = [];
				$data['allowedAddressStates'] = [];
				foreach ($allowedCountries as $allowedAddressCountry) {
					array_push($data['allowedAddressCountries'], $allowedAddressCountry['iso_code_2']);

					$allowedStates = $this->model_localisation_zone->getZonesByCountryId($allowedAddressCountry['country_id']);
					if (count($allowedStates)) {
						$tempArray = [
							$allowedAddressCountry['iso_code_2'] => []
						];
						foreach ($allowedStates as $allowedAddressState) {
							array_push($tempArray[$allowedAddressCountry['iso_code_2']], [
								$allowedAddressState['zone_id'] => $allowedAddressState['name']
							]);
						}
						array_push($data['allowedAddressStates'], $tempArray);
					}
				}
				$data['allowedAddressCountries'] = json_encode($data['allowedAddressCountries']);
				$data['allowedAddressStates'] = str_replace("'", '', str_replace(',{', ',', str_replace('},', ',', str_replace(']', '', str_replace('[', '', json_encode($data['allowedAddressStates']))))));
				$data['button_width'] = $setting['button_width'][$data['button_size']];
				$data['message_width'] = $setting['message_width'][$data['message_size']];
				$data['lang'] = explode("-", $this->session->data['language'])[0];
				if (!isset($this->session->data['order_id'])) {
					$this->createOrderInDB();
				}
				$data['order_id'] = $this->session->data['order_id'];

				return $this->load->view('extension/module/amwal_smart_button', $data);
			}
		}

		return '';
	}
	public function getOrderInfo()
	{
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		$data['lang'] = $this->language->get('code');
		$shipping_info = array();

		if ($this->cart->hasShipping()) {
			$shipping_info['name']['full_name'] = $order_info['shipping_firstname'];
			$shipping_info['name']['full_name'] .= ($order_info['shipping_lastname'] ? (' ' . $order_info['shipping_lastname']) : '');
			$shipping_info['address']['address_line_1'] = $order_info['shipping_address_1'];
			$shipping_info['address']['address_line_2'] = $order_info['shipping_address_2'];
			$shipping_info['address']['admin_area_1'] = $order_info['shipping_zone'];
			$shipping_info['address']['admin_area_2'] = $order_info['shipping_city'];
			$shipping_info['address']['postal_code'] = $order_info['shipping_postcode'];

			if ($order_info['shipping_country_id']) {
				$this->load->model('localisation/country');

				$country_info = $this->model_localisation_country->getCountry($order_info['shipping_country_id']);

				if ($country_info) {
					$shipping_info['address']['country_code'] = $country_info['iso_code_2'];
				}
			}

			$shipping_preference = 'SET_PROVIDED_ADDRESS';
		} else {
			$shipping_preference = 'NO_SHIPPING';
		}

		$item_info = array();
		$item_total = 0;
		$tax_total = 0;
		$currency_value = $this->currency->getValue($this->session->data['currency']);
		$decimal_place = 2;
		$currency_code = $this->session->data['currency'];
		foreach ($this->cart->getProducts() as $product) {
			$product_price = number_format($product['price'] * $currency_value, $decimal_place, '.', '');

			$item_info[] = array(
				'name' => $product['name'],
				'sku' => $product['model'],
				'url' => $this->url->link('product/product', 'product_id=' . $product['product_id'], true),
				'quantity' => $product['quantity'],
				'unit_amount' => array(
					'currency_code' => $currency_code,
					'value' => $product_price
				)
			);

			$item_total += $product_price * $product['quantity'];

			if ($product['tax_class_id']) {
				$tax_rates = $this->tax->getRates($product['price'], $product['tax_class_id']);

				foreach ($tax_rates as $tax_rate) {
					$tax_total += ($tax_rate['amount'] * $product['quantity']);
				}
			}
		}

		$item_total = number_format($item_total, $decimal_place, '.', '');
		$tax_total = number_format($tax_total * $currency_value, $decimal_place, '.', '');

		$discount_total = 0;
		$handling_total = 0;
		$shipping_total = 0;
		if (isset($this->session->data['shipping_method'])) {
			$shipping_total = $this->session->data['shipping_method']['cost'];
			$shipping_total = number_format($shipping_total * $currency_value, $decimal_place, '.', '');
			$data['shippingMethods'] = array(
				[
					'price' => $this->session->data['shipping_method']['cost'],
					'id' => $this->session->data['shipping_method']['code'],
					'label' => $this->session->data['shipping_method']['title'],

				]
			);
		}

		$order_total = number_format($order_info['total'] * $currency_value, $decimal_place, '.', '');
		$rebate = number_format($item_total + $tax_total + $shipping_total - $order_total, $decimal_place, '.', '');

		if ($rebate > 0) {
			$discount_total = $rebate;
		} elseif ($rebate < 0) {
			$handling_total = -$rebate;
		}

		$amount_info = array(
			'currency_code' => $currency_code,
			'value' => $order_total,
			'shippingMethods' => isset($this->session->data['shipping_method']) ? $data['shippingMethods'] : null,
			'breakdown' => array(
				'item_total' => array(
					'currency_code' => $currency_code,
					'value' => $item_total
				),
				'tax_total' => array(
					'currency_code' => $currency_code,
					'value' => $tax_total
				),
				'shipping' => array(
					'currency_code' => $currency_code,
					'value' => $shipping_total
				),
				'handling' => array(
					'currency_code' => $currency_code,
					'value' => $handling_total
				),
				'discount' => array(
					'currency_code' => $currency_code,
					'value' => $discount_total
				)
			)
		);
		return $amount_info;
	}
	public function approveOrder(): void
	{
		$this->load->language('extension/payment/amwal');

		$this->load->model('extension/payment/amwal');
		$this->load->model('checkout/order');
		$this->load->model('checkout/order');
		// Setting
		$_config = new Config();
		$_config->load('amwal');

		$config_setting = $_config->get('amwal_setting');

		$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('payment_amwal_setting'));
		$amwal_api_key_value = $this->config->get('payment_amwal_api_key');
		$amwal_info = [
			'payment_amwal_api_key' => $amwal_api_key_value
		];
		require_once DIR_SYSTEM . 'library/amwal/amwal.php';

		$amwal = new Amwal($amwal_info);
		if (isset($this->request->post['orderId'])) {
			$order_status = $amwal->checkOrderStatus($this->request->post['orderId']);
			$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

			$order_info['customer_id'] = '';
			$this->load->model('account/customer');
			if (isset($this->session->data['customer_id'])) {
				$customer = $this->model_account_customer->getCustomer($this->session->data['customer_id']);
				$order_info['customer_group_id'] = $customer['customer_group_id'];
			} else {
				$order_info['customer_group_id'] = '1';
			}
			$order_info['firstname'] = $order_status['client_first_name'];
			$order_info['lastname'] = $order_status['client_last_name'];
			$order_info['email'] = $order_status['client_email'];
			$order_info['telephone'] = $order_status['client_phone_number'];
			if ($this->cart->hasShipping()) {
				$shippingZone = json_decode($this->getShippingZone($order_status['address_details']));
				$order_info['payment_firstname'] = $order_status['client_first_name'];
				$order_info['payment_lastname'] = $order_status['client_last_name'];
				$order_info['payment_company'] = '';
				$order_info['payment_address_1'] = $order_status['address_details']['street1'];
				$order_info['payment_address_2'] = isset($order_status['address_details']['street1']) ? $order_status['address_details']['street1'] : '';
				$order_info['payment_city'] = $order_status['address_details']['city'];
				$order_info['payment_postcode'] = $order_status['address_details']['postcode'];
				$order_info['payment_zone'] = $order_status['address_details']['state'];
				$order_info['payment_zone_id'] = $shippingZone->zone_id;
				$order_info['payment_country'] = $order_status['address_details']['country'];
				$order_info['payment_country_id'] = $shippingZone->country_id;
				$order_info['payment_address_format'] = "{firstname} {lastname}
			{company}
			{address_1}
			{address_2}
			{city}, {zone} {postcode}
			{country}";
			}
			$order_info['payment_method'] = 'Amwal Quick checkout';


			$order_info['payment_code'] = 'amwal';
			$order_info['payment_custom_field'] = array(
				'transaction_id' => $order_status['id']
			);


			if ($this->cart->hasShipping()) {
				$order_info['shipping_firstname'] = $order_status['client_first_name'];
				$order_info['shipping_lastname'] = $order_status['client_last_name'];
				$order_info['shipping_company'] = '';
				$order_info['shipping_address_1'] = $order_status['address_details']['street1'];
				$order_info['shipping_address_2'] = isset($order_status['address_details']['street1']) ? $order_status['address_details']['street1'] : '';
				$order_info['shipping_city'] = $order_status['address_details']['city'];
				$order_info['shipping_postcode'] = $order_status['address_details']['postcode'];
				$order_info['shipping_zone'] = $order_status['address_details']['state'];
				$order_info['shipping_zone_id'] = $shippingZone->zone_id;
				$order_info['shipping_country'] = $order_status['address_details']['country'];
				$order_info['shipping_country_id'] = $shippingZone->country_id;
				$order_info['shipping_address_format'] = "{firstname} {lastname}
				{company}
				{address_1}
				{address_2}
				{city}, {zone} {postcode}
				{country}";


				if (isset($order_status['shipping_details']['label'])) {
					$order_info['shipping_method'] = $order_status['shipping_details']['label'];
				} else {
					$order_info['shipping_method'] = '';
				}

				if (isset($order_status['shipping_details']['id'])) {
					$order_info['shipping_code'] = $order_status['shipping_details']['id'];
				} else {
					$order_info['shipping_code'] = '';
				}
				$this->session->data['shipping_method'] = array(
					'cost' => $order_status['shipping_details']['inital_price'],
					'tax_class_id' => $order_status['shipping_details']['tax_class_id'],
					'code' => $order_status['shipping_details']['id'],
					'title' => $order_status['shipping_details']['label']
				);
			} else {
				$order_info['shipping_firstname'] = '';
				$order_info['shipping_lastname'] = '';
				$order_info['shipping_company'] = '';
				$order_info['shipping_address_1'] = '';
				$order_info['shipping_address_2'] = '';
				$order_info['shipping_city'] = '';
				$order_info['shipping_postcode'] = '';
				$order_info['shipping_zone'] = '';
				$order_info['shipping_zone_id'] = '';
				$order_info['shipping_country'] = '';
				$order_info['shipping_country_id'] = '';
				$order_info['shipping_address_format'] = '';
				$order_info['shipping_custom_field'] = array();
				$order_info['shipping_method'] = '';
				$order_info['shipping_code'] = '';
			}
			$order_info['invoice_prefix'] = $this->config->get('config_invoice_prefix');
			$order_info['store_id'] = $this->config->get('config_store_id');
			$order_info['store_name'] = $this->config->get('config_name');

			if ($order_info['store_id']) {
				$order_info['store_url'] = $this->config->get('config_url');
			} else {
				if ($this->request->server['HTTPS']) {
					$order_info['store_url'] = HTTPS_SERVER;
				} else {
					$order_info['store_url'] = HTTP_SERVER;
				}
			}
			$order_info['products'] = array();

			foreach ($this->cart->getProducts() as $product) {
				$option_data = array();

				foreach ($product['option'] as $option) {
					$option_data[] = array(
						'product_option_id' => $option['product_option_id'],
						'product_option_value_id' => $option['product_option_value_id'],
						'option_id' => $option['option_id'],
						'option_value_id' => $option['option_value_id'],
						'name' => $option['name'],
						'value' => $option['value'],
						'type' => $option['type']
					);
				}

				$order_info['products'][] = array(
					'product_id' => $product['product_id'],
					'name' => $product['name'],
					'model' => $product['model'],
					'option' => $option_data,
					'download' => $product['download'],
					'quantity' => $product['quantity'],
					'subtract' => $product['subtract'],
					'price' => $product['price'],
					'total' => $product['total'],
					'tax' => $this->tax->getTax($product['price'], $product['tax_class_id']),
					'reward' => $product['reward']
				);
			}
			// Gift Voucher
			$order_info['vouchers'] = array();

			if (!empty($this->session->data['vouchers'])) {
				foreach ($this->session->data['vouchers'] as $voucher) {
					$order_info['vouchers'][] = array(
						'description' => $voucher['description'],
						'code' => token(10),
						'to_name' => $voucher['to_name'],
						'to_email' => $voucher['to_email'],
						'from_name' => $voucher['from_name'],
						'from_email' => $voucher['from_email'],
						'voucher_theme_id' => $voucher['voucher_theme_id'],
						'message' => $voucher['message'],
						'amount' => $voucher['amount']
					);
				}
			}

			$order_info['comment'] = (isset($this->session->data['comment']) ? $this->session->data['comment'] : '');

			if (isset($this->request->cookie['tracking'])) {
				$order_info['tracking'] = $this->request->cookie['tracking'];

				$sub_total = $this->cart->getSubTotal();

				// Affiliate
				$this->load->model('account/customer');

				$affiliate_info = $this->model_account_customer->getAffiliateByTracking($this->request->cookie['tracking']);

				if ($affiliate_info) {
					$order_info['affiliate_id'] = $affiliate_info['customer_id'];
					$order_info['commission'] = ($sub_total / 100) * $affiliate_info['commission'];
				} else {
					$order_info['affiliate_id'] = 0;
					$order_info['commission'] = 0;
				}

				// Marketing
				$this->load->model('checkout/marketing');

				$marketing_info = $this->model_checkout_marketing->getMarketingByCode($this->request->cookie['tracking']);

				if ($marketing_info) {
					$order_info['marketing_id'] = $marketing_info['marketing_id'];
				} else {
					$order_info['marketing_id'] = 0;
				}
			} else {
				$order_info['affiliate_id'] = 0;
				$order_info['commission'] = 0;
				$order_info['marketing_id'] = 0;
				$order_info['tracking'] = '';
			}

			$order_info['language_id'] = $this->config->get('config_language_id');
			$order_info['currency_id'] = $this->currency->getId($this->session->data['currency']);
			$order_info['currency_code'] = $this->session->data['currency'];
			$order_info['currency_value'] = $this->currency->getValue($this->session->data['currency']);
			$order_info['ip'] = $this->request->server['REMOTE_ADDR'];

			if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
				$order_info['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
			} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
				$order_info['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
			} else {
				$order_info['forwarded_ip'] = '';
			}

			if (isset($this->request->server['HTTP_USER_AGENT'])) {
				$order_info['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
			} else {
				$order_info['user_agent'] = '';
			}

			if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
				$order_info['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
			} else {
				$order_info['accept_language'] = '';
			}

			$totals = array();
			$taxes = $this->cart->getTaxes();
			$total = 0;

			// Because __call can not keep var references so we put them into an array.
			$total_data = array(
				'totals' => &$totals,
				'taxes' => &$taxes,
				'total' => &$total
			);

			$this->load->model('setting/extension');

			$sort_order = array();

			$results = $this->model_setting_extension->getExtensions('total');

			foreach ($results as $key => $value) {
				$sort_order[$key] = $this->config->get('total_' . $value['code'] . '_sort_order');
			}

			array_multisort($sort_order, SORT_ASC, $results);

			foreach ($results as $result) {
				if ($this->config->get('total_' . $result['code'] . '_status')) {
					$this->load->model('extension/total/' . $result['code']);

					// We have to put the totals in an array so that they pass by reference.
					$this->{'model_extension_total_' . $result['code']}->getTotal($total_data);
				}
			}

			$sort_order = array();

			foreach ($totals as $key => $value) {
				$sort_order[$key] = $value['sort_order'];
			}

			array_multisort($sort_order, SORT_ASC, $totals);
			$currency_value = $this->currency->getValue($this->session->data['currency']);
			$decimal_place = 2;
			$currency_code = $this->session->data['currency'];
			$order_info['totals'] = $totals;
			$order_info['total'] = $total_data['total'];
			$this->model_checkout_order->editOrder($this->session->data['order_id'], $order_info);
			$oc_order_info = $this->getOrderInfo();
			$amount = $oc_order_info['breakdown']['item_total']['value'];
			$taxes = $oc_order_info['breakdown']['tax_total']['value'];
			$discount = $oc_order_info['breakdown']['discount']['value'];
			$shippingMethods = $oc_order_info['breakdown']['shipping']['value'];

			$total = $oc_order_info['value'];

			if ($order_status['total_amount'] === number_format($total * $currency_value, $decimal_place, '.', '')) {
				$order_data['transaction_id'] = $order_status['id'];
				$order_data['products'] = [];

				foreach ($this->cart->getProducts() as $product) {
					$option_data = [];

					foreach ($product['option'] as $option) {
						$option_data[] = [
							'product_option_id' => $option['product_option_id'],
							'product_option_value_id' => $option['product_option_value_id'],
							'option_id' => $option['option_id'],
							'option_value_id' => $option['option_value_id'],
							'name' => $option['name'],
							'value' => $option['value'],
							'type' => $option['type']
						];
					}

					$order_data['products'][] = [
						'product_id' => $product['product_id'],
						'name' => $product['name'],
						'model' => $product['model'],
						'option' => $option_data,
						'subscription' => $product['recurring'],
						'download' => $product['download'],
						'quantity' => $product['quantity'],
						'subtract' => $product['subtract'],
						'price' => $product['price'],
						'total' => $product['total'],
						'tax' => $this->tax->getTax($product['price'], $product['tax_class_id']),
						'reward' => $product['reward']
					];
				}

				// Gift Voucher
				$order_data['vouchers'] = [];

				if (!empty($this->session->data['vouchers'])) {
					foreach ($this->session->data['vouchers'] as $voucher) {
						$order_data['vouchers'][] = [
							'description' => $voucher['description'],
							'code' => token(10),
							'to_name' => $voucher['to_name'],
							'to_email' => $voucher['to_email'],
							'from_name' => $voucher['from_name'],
							'from_email' => $voucher['from_email'],
							'voucher_theme_id' => $voucher['voucher_theme_id'],
							'message' => $voucher['message'],
							'amount' => $voucher['amount']
						];
					}
				}

				$order_data['comment'] = (isset($this->session->data['comment']) ? $this->session->data['comment'] : '');

				$this->load->model('checkout/order');
				if ($order_status['status'] == 'success') {
					$order_status_id = $setting['order_status']['processing']['id'];
					$transaction_id = $order_data['transaction_id'];
					$this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $order_status_id, (isset($this->session->data['comment']) ? $this->session->data['comment'] : ''));
					$data['redirect'] = $this->url->link('checkout/success', '', true);
				} else {
					$order_status_id = $setting['order_status']['failed']['id'];
					$transaction_id = $order_data['transaction_id'];
					$this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $order_status_id, (isset($this->session->data['comment']) ? $this->session->data['comment'] : ''));
					$data['redirect'] = $this->url->link('checkout/fail', '', true);
				}
				$order_data['info'] = $oc_order_info;
				$order_position = '';
				if ($this->request->get['position'] == 'product') {
					$order_position = 'product_page';
				} elseif ($this->request->get['position'] == 'cart') {
					$order_position = 'cart_page';

				} else {
					$order_position = 'checkout_page';
				}
				$order_details = [
					'order_url' => $data['redirect'],
					'order_position' => $order_position,
					'order_id' => $this->session->data['order_id'],
					'plugin_version' => 'opencart_1.12',
					'order_status' => $order_status['status'] == 'success' ? $setting['order_status']['processing']['code'] : $setting['order_status']['failed']['code'],
					'order_content' => json_encode($order_data),
				];

				$amwal->addOrderDetails($order_data['transaction_id'], $order_details);
				$this->response->addHeader('Content-Type: application/json');
				$this->response->setOutput(json_encode($data));
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$data['language'] = $this->config->get('config_language');

		$data['error'] = $this->error;
		$this->response->setOutput(json_encode($data));
	}

	public function createOrder(): void
	{
		$this->load->language('extension/module/amwal_smart_button');

		$this->load->model('extension/module/amwal_smart_button');
		$errors = [];

		$data['order_id'] = '';
		if (isset($this->request->post['product_id'])) {
			$product_id = (int) $this->request->post['product_id'];

			$this->load->model('catalog/product');

			$product_info = $this->model_catalog_product->getProduct($product_id);
			if ($product_info['quantity'] == 0) {
				array_push($errors, 'Not in stock');
				$this->error['warning'] = implode(' ', $errors);
				$data['error'] = $this->error;

				$this->response->addHeader('Content-Type: application/json');
				$this->response->setOutput(json_encode($data));
			}

			if ($product_info && $product_info['quantity'] != 0) {
				if (isset($this->request->post['quantity'])) {
					$quantity = (int) $this->request->post['quantity'];
				} else {
					$quantity = 1;
				}

				if (isset($this->request->post['option'])) {
					$option = array_filter($this->request->post['option']);
				} else {
					$option = [];
				}

				$product_options = $this->model_catalog_product->getProductOptions($this->request->post['product_id']);

				foreach ($product_options as $product_option) {
					if ($product_option['required'] && empty($option[$product_option['product_option_id']])) {
						$errors[] = sprintf($this->language->get('error_required'), $product_option['name']);
					}
				}

				if (isset($this->request->post['recurring_id'])) {
					$recurring_id = $this->request->post['recurring_id'];
				} else {
					$recurring_id = 0;
				}

				$recurrings = $this->model_catalog_product->getProfiles($product_info['product_id']);

				if ($recurrings) {
					$recurring_ids = array();

					foreach ($recurrings as $recurring) {
						$recurring_ids[] = $recurring['recurring_id'];
					}

					if (!in_array($recurring_id, $recurring_ids)) {
						$errors[] = $this->language->get('error_recurring_required');
					}
				}

				if (!$errors) {
					if (!$this->model_extension_module_amwal_smart_button->hasProductInCart($this->request->post['product_id'], $option, $recurring_id)) {
						$this->cart->add($this->request->post['product_id'], $quantity, $option, $recurring_id);
					}
					// Unset all shipping and payment methods
					unset($this->session->data['shipping_method']);
					unset($this->session->data['shipping_methods']);
					unset($this->session->data['payment_method']);
					unset($this->session->data['payment_methods']);
					$this->createOrderInDB();
					if ($this->cart->hasShipping()) {
						$data['amwal_address_required_value'] = $this->config->get('payment_amwal_address_required');
						$this->response->addHeader('Content-Type: application/json');
						$data['order_id'] = $this->session->data['order_id'];
						$this->response->setOutput(json_encode($data));
					}
				}

				if ($errors) {
					$this->error['warning'] = implode(' ', $errors);
					$data['error'] = $this->error;

					$this->response->addHeader('Content-Type: application/json');
					$this->response->setOutput(json_encode($data));
				}
			}
		} else {
			$this->createOrderInDB();
		}
	}
	private function createOrderInDB()
	{
		$order_data = array();

		$totals = array();
		$taxes = $this->cart->getTaxes();
		$total = 0;

		// Because __call can not keep var references so we put them into an array.
		$total_data = array(
			'totals' => &$totals,
			'taxes' => &$taxes,
			'total' => &$total
		);

		$this->load->model('setting/extension');

		$sort_order = array();

		$results = $this->model_setting_extension->getExtensions('total');

		foreach ($results as $key => $value) {
			$sort_order[$key] = $this->config->get('total_' . $value['code'] . '_sort_order');
		}

		array_multisort($sort_order, SORT_ASC, $results);

		foreach ($results as $result) {
			if ($this->config->get('total_' . $result['code'] . '_status')) {
				$this->load->model('extension/total/' . $result['code']);

				// We have to put the totals in an array so that they pass by reference.
				$this->{'model_extension_total_' . $result['code']}->getTotal($total_data);
			}
		}

		$sort_order = array();

		foreach ($totals as $key => $value) {
			$sort_order[$key] = $value['sort_order'];
		}

		array_multisort($sort_order, SORT_ASC, $totals);

		$order_data['totals'] = $totals;

		$order_data['invoice_prefix'] = $this->config->get('config_invoice_prefix');
		$order_data['store_id'] = $this->config->get('config_store_id');
		$order_data['store_name'] = $this->config->get('config_name');

		if ($order_data['store_id']) {
			$order_data['store_url'] = $this->config->get('config_url');
		} else {
			if ($this->request->server['HTTPS']) {
				$order_data['store_url'] = HTTPS_SERVER;
			} else {
				$order_data['store_url'] = HTTP_SERVER;
			}
		}

		$order_data['customer_id'] = '';
		$order_data['customer_group_id'] = '';
		$order_data['firstname'] = '';
		$order_data['lastname'] = '';
		$order_data['email'] = '';
		$order_data['telephone'] = '';
		$order_data['custom_field'] = '';

		$order_data['payment_firstname'] = '';
		$order_data['payment_lastname'] = '';
		$order_data['payment_company'] = '';
		$order_data['payment_address_1'] = '';
		$order_data['payment_address_2'] = '';
		$order_data['payment_city'] = '';
		$order_data['payment_postcode'] = '';
		$order_data['payment_zone'] = '';
		$order_data['payment_zone_id'] = '';
		$order_data['payment_country'] = '';
		$order_data['payment_country_id'] = '';
		$order_data['payment_address_format'] = '';
		$order_data['payment_custom_field'] = '';

		if (isset($this->session->data['payment_method']['title'])) {
			$order_data['payment_method'] = $this->session->data['payment_method']['title'];
		} else {
			$order_data['payment_method'] = '';
		}

		if (isset($this->session->data['payment_method']['code'])) {
			$order_data['payment_code'] = $this->session->data['payment_method']['code'];
		} else {
			$order_data['payment_code'] = '';
		}

		if ($this->cart->hasShipping()) {
			$order_data['shipping_firstname'] = '';
			$order_data['shipping_lastname'] = '';
			$order_data['shipping_company'] = '';
			$order_data['shipping_address_1'] = '';
			$order_data['shipping_address_2'] = '';
			$order_data['shipping_city'] = '';
			$order_data['shipping_postcode'] = '';
			$order_data['shipping_zone'] = '';
			$order_data['shipping_zone_id'] = '';
			$order_data['shipping_country'] = '';
			$order_data['shipping_country_id'] = '';
			$order_data['shipping_address_format'] = '';
			$order_data['shipping_custom_field'] = '';

			if (isset($this->session->data['shipping_method']['title'])) {
				$order_data['shipping_method'] = $this->session->data['shipping_method']['title'];
			} else {
				$order_data['shipping_method'] = '';
			}

			if (isset($this->session->data['shipping_method']['code'])) {
				$order_data['shipping_code'] = $this->session->data['shipping_method']['code'];
			} else {
				$order_data['shipping_code'] = '';
			}
		} else {
			$order_data['shipping_firstname'] = '';
			$order_data['shipping_lastname'] = '';
			$order_data['shipping_company'] = '';
			$order_data['shipping_address_1'] = '';
			$order_data['shipping_address_2'] = '';
			$order_data['shipping_city'] = '';
			$order_data['shipping_postcode'] = '';
			$order_data['shipping_zone'] = '';
			$order_data['shipping_zone_id'] = '';
			$order_data['shipping_country'] = '';
			$order_data['shipping_country_id'] = '';
			$order_data['shipping_address_format'] = '';
			$order_data['shipping_custom_field'] = array();
			$order_data['shipping_method'] = '';
			$order_data['shipping_code'] = '';
		}

		$order_data['products'] = array();

		foreach ($this->cart->getProducts() as $product) {
			$option_data = array();

			foreach ($product['option'] as $option) {
				$option_data[] = array(
					'product_option_id' => $option['product_option_id'],
					'product_option_value_id' => $option['product_option_value_id'],
					'option_id' => $option['option_id'],
					'option_value_id' => $option['option_value_id'],
					'name' => $option['name'],
					'value' => $option['value'],
					'type' => $option['type']
				);
			}

			$order_data['products'][] = array(
				'product_id' => $product['product_id'],
				'name' => $product['name'],
				'model' => $product['model'],
				'option' => $option_data,
				'download' => $product['download'],
				'quantity' => $product['quantity'],
				'subtract' => $product['subtract'],
				'price' => $product['price'],
				'total' => $product['total'],
				'tax' => $this->tax->getTax($product['price'], $product['tax_class_id']),
				'reward' => $product['reward']
			);
		}
		// Gift Voucher
		$order_data['vouchers'] = array();

		if (!empty($this->session->data['vouchers'])) {
			foreach ($this->session->data['vouchers'] as $voucher) {
				$order_data['vouchers'][] = array(
					'description' => $voucher['description'],
					'code' => token(10),
					'to_name' => $voucher['to_name'],
					'to_email' => $voucher['to_email'],
					'from_name' => $voucher['from_name'],
					'from_email' => $voucher['from_email'],
					'voucher_theme_id' => $voucher['voucher_theme_id'],
					'message' => $voucher['message'],
					'amount' => $voucher['amount']
				);
			}
		}

		$order_data['comment'] = (isset($this->session->data['comment']) ? $this->session->data['comment'] : '');
		$order_data['total'] = $total_data['total'];

		if (isset($this->request->cookie['tracking'])) {
			$order_data['tracking'] = $this->request->cookie['tracking'];

			$sub_total = $this->cart->getSubTotal();

			// Affiliate
			$this->load->model('account/customer');

			$affiliate_info = $this->model_account_customer->getAffiliateByTracking($this->request->cookie['tracking']);

			if ($affiliate_info) {
				$order_data['affiliate_id'] = $affiliate_info['customer_id'];
				$order_data['commission'] = ($sub_total / 100) * $affiliate_info['commission'];
			} else {
				$order_data['affiliate_id'] = 0;
				$order_data['commission'] = 0;
			}

			// Marketing
			$this->load->model('checkout/marketing');

			$marketing_info = $this->model_checkout_marketing->getMarketingByCode($this->request->cookie['tracking']);

			if ($marketing_info) {
				$order_data['marketing_id'] = $marketing_info['marketing_id'];
			} else {
				$order_data['marketing_id'] = 0;
			}
		} else {
			$order_data['affiliate_id'] = 0;
			$order_data['commission'] = 0;
			$order_data['marketing_id'] = 0;
			$order_data['tracking'] = '';
		}

		$order_data['language_id'] = $this->config->get('config_language_id');
		$order_data['currency_id'] = $this->currency->getId($this->session->data['currency']);
		$order_data['currency_code'] = $this->session->data['currency'];
		$order_data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
		$order_data['ip'] = $this->request->server['REMOTE_ADDR'];

		if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
			$order_data['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
		} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
			$order_data['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
		} else {
			$order_data['forwarded_ip'] = '';
		}

		if (isset($this->request->server['HTTP_USER_AGENT'])) {
			$order_data['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
		} else {
			$order_data['user_agent'] = '';
		}

		if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
			$order_data['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
		} else {
			$order_data['accept_language'] = '';
		}
		$_config = new Config();
		$_config->load('amwal');
		$config_setting = $_config->get('amwal_setting');
		$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('payment_amwal_setting'));
		$order_data['order_status_id'] = $setting['order_status']['pending']['id'];
		$this->load->model('checkout/order');
		if (isset($this->session->data['order_id'])) {
			$this->model_checkout_order->editOrder($this->session->data['order_id'], $order_data);

		} else {
			$this->session->data['order_id'] = $this->model_checkout_order->addOrder($order_data);
		}
	}
	public function getShippingMethods($address): string
	{
		$this->load->model('localisation/country');
		$this->load->model('localisation/zone');
		$this->load->model('checkout/shipping_method');

		$country_id = (int) $this->model_localisation_country->getCountryByIsoCode2($address['country'])['country_id'];
		$zones = $this->model_localisation_zone->getZonesByCountryId($country_id);
		$zone_id = 1;
		$city = str_replace('-', ' ', $address['city']);
		foreach ($zones as $zoneItem) {
			if (strtolower($zoneItem['name']) == strtolower($city)) {
				$zone_id = (int) $zoneItem['zone_id'];
				break;
			}
		}


		$data['zone_id'] = $zone_id;
		$data['country_id'] = $country_id;
		$shipping_methods = $this->model_checkout_shipping_method->getMethods($data);
		return json_encode($shipping_methods);
	}

	public function getShippingZone($address): string
	{
		$this->load->model('localisation/country');
		$this->load->model('localisation/zone');

		$this->load->model('extension/module/amwal_smart_button');

		$country_id = (int) $this->model_extension_module_amwal_smart_button->getCountryByCode($address['country'])['country_id'];

		$zones = $this->model_localisation_zone->getZonesByCountryId($country_id);
		$zone_id = 1;
		if (isset($address['state_code'])) {
			$zone_id = $address['state_code'];
		} else {
			$city = str_replace('-', ' ', $address['city']);
			foreach ($zones as $zoneItem) {
				if (strtolower($zoneItem['name']) == strtolower($city)) {
					$zone_id = (int) $zoneItem['zone_id'];
					break;
				}
			}
		}


		$data['zone_id'] = $zone_id;
		$data['country_id'] = $country_id;

		return json_encode($data);
	}

	public function createInitialOrder()
	{
		$this->load->language('extension/payment/amwal');

		$this->load->model('extension/payment/amwal');
		$this->load->model('checkout/order');

		// Setting
		$_config = new Config();
		$_config->load('amwal');
		$config_setting = $_config->get('amwal_setting');
		$currency_value = $this->currency->getValue($this->session->data['currency']);
		$decimal_place = 2;
		$currency_code = $this->session->data['currency'];
		$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('payment_amwal_setting'));
		$amwal_api_key_value = $this->config->get('payment_amwal_api_key');
		$amwal_info = [
			'payment_amwal_api_key' => $amwal_api_key_value
		];
		require_once DIR_SYSTEM . 'library/amwal/amwal.php';

		$amwal = new Amwal($amwal_info);
		if (isset($this->request->post['orderId'])) {
			$order_status = $amwal->checkOrderStatus($this->request->post['orderId']);
			$order_info = $this->model_checkout_order->getOrder(isset($order_status['ref_id']) ? $order_status['ref_id'] : $this->session->data['order_id']);

			$order_info['customer_id'] = '';
			$this->load->model('account/customer');
			if (isset($this->session->data['customer_id'])) {
				$customer = $this->model_account_customer->getCustomer($this->session->data['customer_id']);
				$order_info['customer_group_id'] = $customer['customer_group_id'];
			} else {
				$order_info['customer_group_id'] = '1';
			}
			$order_info['firstname'] = $order_status['client_first_name'];
			$order_info['lastname'] = $order_status['client_last_name'];
			$order_info['email'] = $order_status['client_email'];
			$order_info['telephone'] = $order_status['client_phone_number'];
			if ($this->cart->hasShipping()) {
				$shippingZone = json_decode($this->getShippingZone($order_status['address_details']));
				$order_info['payment_firstname'] = $order_status['client_first_name'];
				$order_info['payment_lastname'] = $order_status['client_last_name'];
				$order_info['payment_company'] = '';
				$order_info['payment_address_1'] = $order_status['address_details']['street1'];
				$order_info['payment_address_2'] = isset($order_status['address_details']['street1']) ? $order_status['address_details']['street1'] : '';
				$order_info['payment_city'] = $order_status['address_details']['city'];
				$order_info['payment_postcode'] = $order_status['address_details']['postcode'];
				$order_info['payment_zone'] = $order_status['address_details']['state'];
				$order_info['payment_zone_id'] = $shippingZone->zone_id;
				$order_info['payment_country'] = $order_status['address_details']['country'];
				$order_info['payment_country_id'] = $shippingZone->country_id;
				$order_info['payment_address_format'] = "{firstname} {lastname}
			{company}
			{address_1}
			{address_2}
			{city}, {zone} {postcode}
			{country}";
			}
			$order_info['payment_method'] = 'Amwal Quick checkout';


			$order_info['payment_code'] = 'amwal';
			$order_info['payment_custom_field'] = array(
				'transaction_id' => $order_status['id']
			);


			if ($this->cart->hasShipping()) {
				$order_info['shipping_firstname'] = $order_status['client_first_name'];
				$order_info['shipping_lastname'] = $order_status['client_last_name'];
				$order_info['shipping_company'] = '';
				$order_info['shipping_address_1'] = $order_status['address_details']['street1'];
				$order_info['shipping_address_2'] = isset($order_status['address_details']['street1']) ? $order_status['address_details']['street1'] : '';
				$order_info['shipping_city'] = $order_status['address_details']['city'];
				$order_info['shipping_postcode'] = $order_status['address_details']['postcode'];
				$order_info['shipping_zone'] = $order_status['address_details']['state'];
				$order_info['shipping_zone_id'] = $shippingZone->zone_id;
				$order_info['shipping_country'] = $order_status['address_details']['country'];
				$order_info['shipping_country_id'] = $shippingZone->country_id;
				$order_info['shipping_address_format'] = "{firstname} {lastname}
				{company}
				{address_1}
				{address_2}
				{city}, {zone} {postcode}
				{country}";


				if (isset($order_status['shipping_details']['label'])) {
					$order_info['shipping_method'] = $order_status['shipping_details']['label'];
				} else {
					$order_info['shipping_method'] = '';
				}

				if (isset($order_status['shipping_details']['id'])) {
					$order_info['shipping_code'] = $order_status['shipping_details']['id'];
				} else {
					$order_info['shipping_code'] = '';
				}
				$this->session->data['shipping_method'] = array(
					'cost' => $order_status['shipping_details']['inital_price'],
					'tax_class_id' => $order_status['shipping_details']['tax_class_id'],
					'code' => $order_status['shipping_details']['id'],
					'title' => $order_status['shipping_details']['label']
				);
			} else {
				$order_info['shipping_firstname'] = '';
				$order_info['shipping_lastname'] = '';
				$order_info['shipping_company'] = '';
				$order_info['shipping_address_1'] = '';
				$order_info['shipping_address_2'] = '';
				$order_info['shipping_city'] = '';
				$order_info['shipping_postcode'] = '';
				$order_info['shipping_zone'] = '';
				$order_info['shipping_zone_id'] = '';
				$order_info['shipping_country'] = '';
				$order_info['shipping_country_id'] = '';
				$order_info['shipping_address_format'] = '';
				$order_info['shipping_custom_field'] = array();
				$order_info['shipping_method'] = '';
				$order_info['shipping_code'] = '';
			}
			$order_info['invoice_prefix'] = $this->config->get('config_invoice_prefix');
			$order_info['store_id'] = $this->config->get('config_store_id');
			$order_info['store_name'] = $this->config->get('config_name');

			if ($order_info['store_id']) {
				$order_info['store_url'] = $this->config->get('config_url');
			} else {
				if ($this->request->server['HTTPS']) {
					$order_info['store_url'] = HTTPS_SERVER;
				} else {
					$order_info['store_url'] = HTTP_SERVER;
				}
			}
			$order_info['products'] = array();

			foreach ($this->cart->getProducts() as $product) {
				$option_data = array();

				foreach ($product['option'] as $option) {
					$option_data[] = array(
						'product_option_id' => $option['product_option_id'],
						'product_option_value_id' => $option['product_option_value_id'],
						'option_id' => $option['option_id'],
						'option_value_id' => $option['option_value_id'],
						'name' => $option['name'],
						'value' => $option['value'],
						'type' => $option['type']
					);
				}

				$order_info['products'][] = array(
					'product_id' => $product['product_id'],
					'name' => $product['name'],
					'model' => $product['model'],
					'option' => $option_data,
					'download' => $product['download'],
					'quantity' => $product['quantity'],
					'subtract' => $product['subtract'],
					'price' => $product['price'],
					'total' => $product['total'],
					'tax' => $this->tax->getTax($product['price'], $product['tax_class_id']),
					'reward' => $product['reward']
				);
			}
			// Gift Voucher
			$order_info['vouchers'] = array();

			if (!empty($this->session->data['vouchers'])) {
				foreach ($this->session->data['vouchers'] as $voucher) {
					$order_info['vouchers'][] = array(
						'description' => $voucher['description'],
						'code' => token(10),
						'to_name' => $voucher['to_name'],
						'to_email' => $voucher['to_email'],
						'from_name' => $voucher['from_name'],
						'from_email' => $voucher['from_email'],
						'voucher_theme_id' => $voucher['voucher_theme_id'],
						'message' => $voucher['message'],
						'amount' => $voucher['amount']
					);
				}
			}

			$order_info['comment'] = (isset($this->session->data['comment']) ? $this->session->data['comment'] : '');

			if (isset($this->request->cookie['tracking'])) {
				$order_info['tracking'] = $this->request->cookie['tracking'];

				$sub_total = $this->cart->getSubTotal();

				// Affiliate
				$this->load->model('account/customer');

				$affiliate_info = $this->model_account_customer->getAffiliateByTracking($this->request->cookie['tracking']);

				if ($affiliate_info) {
					$order_info['affiliate_id'] = $affiliate_info['customer_id'];
					$order_info['commission'] = ($sub_total / 100) * $affiliate_info['commission'];
				} else {
					$order_info['affiliate_id'] = 0;
					$order_info['commission'] = 0;
				}

				// Marketing
				$this->load->model('checkout/marketing');

				$marketing_info = $this->model_checkout_marketing->getMarketingByCode($this->request->cookie['tracking']);

				if ($marketing_info) {
					$order_info['marketing_id'] = $marketing_info['marketing_id'];
				} else {
					$order_info['marketing_id'] = 0;
				}
			} else {
				$order_info['affiliate_id'] = 0;
				$order_info['commission'] = 0;
				$order_info['marketing_id'] = 0;
				$order_info['tracking'] = '';
			}

			$order_info['language_id'] = $this->config->get('config_language_id');
			$order_info['currency_id'] = $this->currency->getId($this->session->data['currency']);
			$order_info['currency_code'] = $this->session->data['currency'];
			$order_info['currency_value'] = $this->currency->getValue($this->session->data['currency']);
			$order_info['ip'] = $this->request->server['REMOTE_ADDR'];

			if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
				$order_info['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
			} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
				$order_info['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
			} else {
				$order_info['forwarded_ip'] = '';
			}

			if (isset($this->request->server['HTTP_USER_AGENT'])) {
				$order_info['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
			} else {
				$order_info['user_agent'] = '';
			}

			if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
				$order_info['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
			} else {
				$order_info['accept_language'] = '';
			}

			$totals = array();
			$taxes = $this->cart->getTaxes();
			$total = 0;

			// Because __call can not keep var references so we put them into an array.
			$total_data = array(
				'totals' => &$totals,
				'taxes' => &$taxes,
				'total' => &$total
			);

			$this->load->model('setting/extension');

			$sort_order = array();

			$results = $this->model_setting_extension->getExtensions('total');

			foreach ($results as $key => $value) {
				$sort_order[$key] = $this->config->get('total_' . $value['code'] . '_sort_order');
			}

			array_multisort($sort_order, SORT_ASC, $results);

			foreach ($results as $result) {
				if ($this->config->get('total_' . $result['code'] . '_status')) {
					$this->load->model('extension/total/' . $result['code']);

					// We have to put the totals in an array so that they pass by reference.
					$this->{'model_extension_total_' . $result['code']}->getTotal($total_data);
				}
			}

			$sort_order = array();

			foreach ($totals as $key => $value) {
				$sort_order[$key] = $value['sort_order'];
			}

			array_multisort($sort_order, SORT_ASC, $totals);
			$order_info['totals'] = $totals;
			$order_info['total'] = $total_data['total'];
			$this->model_checkout_order->editOrder($order_info['order_id'], $order_info);
			$data['order_id'] = $order_info['order_id'];
			$data['total'] = number_format($order_info['total'] * $currency_value, $decimal_place, '.', '');
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($data));
		}
	}


	public function handleFix(): void
	{
		$this->load->language('extension/payment/amwal');

		$this->load->model('extension/payment/amwal');
		$this->load->model('checkout/order');

		// Setting
		$_config = new Config();
		$_config->load('amwal');
		$config_setting = $_config->get('amwal_setting');

		$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('payment_amwal_setting'));
		$amwal_api_key_value = $this->config->get('payment_amwal_api_key');
		$amwal_info = [
			'payment_amwal_api_key' => $amwal_api_key_value
		];
		require_once DIR_SYSTEM . 'library/amwal/amwal.php';

		$amwal = new Amwal($amwal_info);
		if (isset($this->request->post['orderId'])) {
			$order_status = $amwal->checkOrderStatus($this->request->post['orderId']);
			$updateOrder = $this->model_checkout_order->getOrder($order_status['ref_id']);

			if ((!isset($updateOrder['order_status']) || !isset($updateOrder['products'])) && (!isset($updateOrder['payment_custom_field']['transaction_id']) || $updateOrder['payment_custom_field']['transaction_id'] == $this->request->post['orderId'])) {
				$order_info['customer_id'] = '';
				$this->load->model('account/customer');
				$this->load->model('catalog/product');
				if (isset($this->session->data['customer_id'])) {
					$customer = $this->model_account_customer->getCustomer($this->session->data['customer_id']);
					$order_info['customer_group_id'] = $customer['customer_group_id'];
				} else {
					$order_info['customer_group_id'] = '1';
				}
				$order_info['firstname'] = $order_status['client_first_name'];
				$order_info['lastname'] = $order_status['client_last_name'];
				if (isset($order_status['client_email'])) {
					$order_info['email'] = $order_status['client_email'];
				} else {
					$order_info['email'] = $updateOrder['email'];
				}
				$order_info['telephone'] = $order_status['client_phone_number'];
				$order_info['products'] = array();
				$products = $this->model_checkout_order->getOrderProducts($order_status['ref_id']);
				foreach ($products as $product) {
					$option_data = array();
					$options = $this->model_checkout_order->getOrderOptions($order_status['ref_id'], $product['order_product_id']);

					$option = [];

					$product_options = $this->model_catalog_product->getProductOptions($product['product_id']);
					foreach ($product_options as $product_option) {
						if ($product_option['required'] && empty($option[$product_option['product_option_id']])) {
							$errors[] = sprintf($this->language->get('error_required'), $product_option['name']);
						}
						foreach ($options as $optiotemp) {
							if ($optiotemp['product_option_id'] == $product_option['product_option_id']) {
								array_push($option, [
									$optiotemp['product_option_id'] => $optiotemp['product_option_value_id']
								]);
							}
						}
					}
					if (isset($this->request->post['recurring_id'])) {
						$recurring_id = $this->request->post['recurring_id'];
					} else {
						$recurring_id = 0;
					}

					$recurrings = $this->model_catalog_product->getProfiles($product['product_id']);

					if ($recurrings) {
						$recurring_ids = array();

						foreach ($recurrings as $recurring) {
							$recurring_ids[] = $recurring['recurring_id'];
						}

						if (!in_array($recurring_id, $recurring_ids)) {
							$errors[] = $this->language->get('error_recurring_required');
						}
					}
					$this->cart->add($product['product_id'], $product['quantity'], isset($option[0]) ? $option[0] : $option, $recurring_id);

				}
				if ($this->cart->hasShipping()) {
					$shippingZone = json_decode($this->getShippingZone($order_status['address_details']));
					$order_info['payment_firstname'] = $order_status['client_first_name'];
					$order_info['payment_lastname'] = $order_status['client_last_name'];
					$order_info['payment_company'] = '';
					$order_info['payment_address_1'] = $order_status['address_details']['street1'];
					$order_info['payment_address_2'] = isset($order_status['address_details']['street1']) ? $order_status['address_details']['street1'] : '';
					$order_info['payment_city'] = $order_status['address_details']['city'];
					$order_info['payment_postcode'] = $order_status['address_details']['postcode'];
					$order_info['payment_zone'] = $order_status['address_details']['state'];
					$order_info['payment_zone_id'] = $shippingZone->zone_id;
					$order_info['payment_country'] = $order_status['address_details']['country'];
					$order_info['payment_country_id'] = $shippingZone->country_id;
					$order_info['payment_address_format'] = "{firstname} {lastname}
				{company}
				{address_1}
				{address_2}
				{city}, {zone} {postcode}
				{country}";
				}
				$order_info['payment_method'] = 'Amwal Quick checkout';


				$order_info['payment_code'] = 'amwal';
				$order_info['payment_custom_field'] = array(
					'transaction_id' => $order_status['id']
				);


				if ($this->cart->hasShipping()) {
					$order_info['shipping_firstname'] = $order_status['client_first_name'];
					$order_info['shipping_lastname'] = $order_status['client_last_name'];
					$order_info['shipping_company'] = '';
					$order_info['shipping_address_1'] = $order_status['address_details']['street1'];
					$order_info['shipping_address_2'] = isset($order_status['address_details']['street1']) ? $order_status['address_details']['street1'] : '';
					$order_info['shipping_city'] = $order_status['address_details']['city'];
					$order_info['shipping_postcode'] = $order_status['address_details']['postcode'];
					$order_info['shipping_zone'] = $order_status['address_details']['state'];
					$order_info['shipping_zone_id'] = $shippingZone->zone_id;
					$order_info['shipping_country'] = $order_status['address_details']['country'];
					$order_info['shipping_country_id'] = $shippingZone->country_id;
					$order_info['shipping_address_format'] = "{firstname} {lastname}
					{company}
					{address_1}
					{address_2}
					{city}, {zone} {postcode}
					{country}";


					if (isset($order_status['shipping_details']['label'])) {
						$order_info['shipping_method'] = $order_status['shipping_details']['label'];
					} else {
						$order_info['shipping_method'] = '';
					}

					if (isset($order_status['shipping_details']['id'])) {
						$order_info['shipping_code'] = $order_status['shipping_details']['id'];
					} else {
						$order_info['shipping_code'] = '';
					}
					$this->session->data['shipping_method'] = array(
						'cost' => $order_status['shipping_details']['price'],
						'tax_class_id' => $order_status['shipping_details']['tax_class_id'],
						'code' => $order_status['shipping_details']['id'],
						'title' => $order_status['shipping_details']['label']
					);
				} else {
					$order_info['shipping_firstname'] = '';
					$order_info['shipping_lastname'] = '';
					$order_info['shipping_company'] = '';
					$order_info['shipping_address_1'] = '';
					$order_info['shipping_address_2'] = '';
					$order_info['shipping_city'] = '';
					$order_info['shipping_postcode'] = '';
					$order_info['shipping_zone'] = '';
					$order_info['shipping_zone_id'] = '';
					$order_info['shipping_country'] = '';
					$order_info['shipping_country_id'] = '';
					$order_info['shipping_address_format'] = '';
					$order_info['shipping_custom_field'] = array();
					$order_info['shipping_method'] = '';
					$order_info['shipping_code'] = '';
				}
				$order_info['invoice_prefix'] = $this->config->get('config_invoice_prefix');
				$order_info['store_id'] = $this->config->get('config_store_id');
				$order_info['store_name'] = $this->config->get('config_name');

				if ($order_info['store_id']) {
					$order_info['store_url'] = $this->config->get('config_url');
				} else {
					if ($this->request->server['HTTPS']) {
						$order_info['store_url'] = HTTPS_SERVER;
					} else {
						$order_info['store_url'] = HTTP_SERVER;
					}
				}
				$order_info['products'] = array();

				foreach ($this->cart->getProducts() as $product) {
					$option_data = array();

					foreach ($product['option'] as $option) {
						$option_data[] = array(
							'product_option_id' => $option['product_option_id'],
							'product_option_value_id' => $option['product_option_value_id'],
							'option_id' => $option['option_id'],
							'option_value_id' => $option['option_value_id'],
							'name' => $option['name'],
							'value' => $option['value'],
							'type' => $option['type']
						);
					}

					$order_info['products'][] = array(
						'product_id' => $product['product_id'],
						'name' => $product['name'],
						'model' => $product['model'],
						'option' => $option_data,
						'download' => $product['download'],
						'quantity' => $product['quantity'],
						'subtract' => $product['subtract'],
						'price' => $product['price'],
						'total' => $product['total'],
						'tax' => $this->tax->getTax($product['price'], $product['tax_class_id']),
						'reward' => $product['reward']
					);
				}
				// Gift Voucher
				$order_info['vouchers'] = array();

				if (!empty($this->session->data['vouchers'])) {
					foreach ($this->session->data['vouchers'] as $voucher) {
						$order_info['vouchers'][] = array(
							'description' => $voucher['description'],
							'code' => token(10),
							'to_name' => $voucher['to_name'],
							'to_email' => $voucher['to_email'],
							'from_name' => $voucher['from_name'],
							'from_email' => $voucher['from_email'],
							'voucher_theme_id' => $voucher['voucher_theme_id'],
							'message' => $voucher['message'],
							'amount' => $voucher['amount']
						);
					}
				}

				$order_info['comment'] = (isset($this->session->data['comment']) ? $this->session->data['comment'] : '');

				if (isset($this->request->cookie['tracking'])) {
					$order_info['tracking'] = $this->request->cookie['tracking'];

					$sub_total = $this->cart->getSubTotal();

					// Affiliate
					$this->load->model('account/customer');

					$affiliate_info = $this->model_account_customer->getAffiliateByTracking($this->request->cookie['tracking']);

					if ($affiliate_info) {
						$order_info['affiliate_id'] = $affiliate_info['customer_id'];
						$order_info['commission'] = ($sub_total / 100) * $affiliate_info['commission'];
					} else {
						$order_info['affiliate_id'] = 0;
						$order_info['commission'] = 0;
					}

					// Marketing
					$this->load->model('checkout/marketing');

					$marketing_info = $this->model_checkout_marketing->getMarketingByCode($this->request->cookie['tracking']);

					if ($marketing_info) {
						$order_info['marketing_id'] = $marketing_info['marketing_id'];
					} else {
						$order_info['marketing_id'] = 0;
					}
				} else {
					$order_info['affiliate_id'] = 0;
					$order_info['commission'] = 0;
					$order_info['marketing_id'] = 0;
					$order_info['tracking'] = '';
				}

				$order_info['language_id'] = $this->config->get('config_language_id');
				$order_info['currency_id'] = $this->currency->getId($this->session->data['currency']);
				$order_info['currency_code'] = $this->session->data['currency'];
				$order_info['currency_value'] = $this->currency->getValue($this->session->data['currency']);
				$order_info['ip'] = $this->request->server['REMOTE_ADDR'];

				if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
					$order_info['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
				} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
					$order_info['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
				} else {
					$order_info['forwarded_ip'] = '';
				}

				if (isset($this->request->server['HTTP_USER_AGENT'])) {
					$order_info['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
				} else {
					$order_info['user_agent'] = '';
				}

				if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
					$order_info['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
				} else {
					$order_info['accept_language'] = '';
				}
				$updateOrder['products'] = $this->cart->getProducts();

				$totals = array();
				$taxes = $this->cart->getTaxes();
				$total = 0;

				// Because __call can not keep var references so we put them into an array.
				$total_data = array(
					'totals' => &$totals,
					'taxes' => &$taxes,
					'total' => &$total
				);

				$this->load->model('setting/extension');
				$sort_order = array();

				$results = $this->model_setting_extension->getExtensions('total');

				foreach ($results as $key => $value) {
					$sort_order[$key] = $this->config->get('total_' . $value['code'] . '_sort_order');
				}

				array_multisort($sort_order, SORT_ASC, $results);

				foreach ($results as $result) {
					if ($this->config->get('total_' . $result['code'] . '_status')) {
						$this->load->model('extension/total/' . $result['code']);

						// We have to put the totals in an array so that they pass by reference.
						$this->{'model_extension_total_' . $result['code']}->getTotal($total_data);
					}
				}

				$sort_order = array();

				foreach ($totals as $key => $value) {
					$sort_order[$key] = $value['sort_order'];
				}

				array_multisort($sort_order, SORT_ASC, $totals);
				$currency_value = $this->currency->getValue($this->session->data['currency']);
				$decimal_place = 2;
				$currency_code = $this->session->data['currency'];
				$order_info['totals'] = $totals;
				$order_info['total'] = $total_data['total'];
				$this->model_checkout_order->editOrder($order_status['ref_id'], $order_info);
				$oc_order_info = $this->getOrderInfo();

				$total = $oc_order_info['value'];
				if ($order_status['status'] == 'success') {
					$order_status_id = $setting['order_status']['processing']['id'];

					$this->model_checkout_order->addOrderHistory($order_status['ref_id'], $order_status_id, (isset($this->session->data['comment']) ? $this->session->data['comment'] : ''));
					$data['redirect'] = $this->url->link('checkout/success', '', true);
				} else {
					$order_status_id = $setting['order_status']['failed']['id'];

					$this->model_checkout_order->addOrderHistory($order_status['ref_id'], $order_status_id, (isset($this->session->data['comment']) ? $this->session->data['comment'] : ''));
					$data['redirect'] = $this->url->link('checkout/fail', '', true);
				}
				$order_details = [
					'order_url' => $data['redirect'],
					'order_position' => 'checkout_page',
					'order_id' => $order_status['ref_id'],
					'plugin_version' => 'opencart_1.12',
					'order_status' => $order_status['status'] == 'success' ? $setting['order_status']['processing']['code'] : $setting['order_status']['failed']['code'],
					'order_content' => json_encode($order_info),
				];

				$amwal->addOrderDetails($order_status['id'], $order_details);
				$this->response->addHeader('Content-Type: application/json');
				$this->response->setOutput(json_encode($updateOrder));
			} else if (isset($updateOrder['payment_custom_field']['transaction_id']) && $updateOrder['payment_custom_field']['transaction_id'] != $this->request->post['orderId']) {
				$this->response->addHeader('Content-Type: application/json');
				$error = array(
					[
						'error' => 'needs refund'
					]
				);
				$this->response->setOutput(json_encode($error));
			} else {
				$this->response->addHeader('Content-Type: application/json');
				$this->response->setOutput(json_encode($updateOrder));
			}
		}
	}

	public function getOrder(): void
	{
		$this->load->language('extension/payment/amwal');

		$this->load->model('extension/payment/amwal');
		$this->load->model('checkout/order');

		// Setting
		$_config = new Config();
		$_config->load('amwal');
		$config_setting = $_config->get('amwal_setting');

		$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('payment_amwal_setting'));
		$amwal_api_key_value = $this->config->get('payment_amwal_api_key');
		$amwal_info = [
			'payment_amwal_api_key' => $amwal_api_key_value
		];
		require_once DIR_SYSTEM . 'library/amwal/amwal.php';
		$this->load->model('catalog/product');

		$amwal = new Amwal($amwal_info);
		if (isset($this->request->post['orderId'])) {
			$order_status = $amwal->checkOrderStatus($this->request->post['orderId']);
			$updateOrder = $this->model_checkout_order->getOrder($order_status['ref_id']);
			$order_info['products'] = array();
			$products = $this->model_checkout_order->getOrderProducts($order_status['ref_id']);
			foreach ($products as $product) {
				$option_data = array();
				$options = $this->model_checkout_order->getOrderOptions($order_status['ref_id'], $product['order_product_id']);

				$option = [];

				$product_options = $this->model_catalog_product->getProductOptions($product['product_id']);
				foreach ($product_options as $product_option) {
					if ($product_option['required'] && empty($option[$product_option['product_option_id']])) {
						$errors[] = sprintf($this->language->get('error_required'), $product_option['name']);
					}
					foreach ($options as $optiotemp) {
						if ($optiotemp['product_option_id'] == $product_option['product_option_id']) {
							array_push($option, [
								$optiotemp['product_option_id'] => $optiotemp['product_option_value_id']
							]);
						}
					}
				}
				if (isset($this->request->post['recurring_id'])) {
					$recurring_id = $this->request->post['recurring_id'];
				} else {
					$recurring_id = 0;
				}

				$recurrings = $this->model_catalog_product->getProfiles($product['product_id']);

				if ($recurrings) {
					$recurring_ids = array();

					foreach ($recurrings as $recurring) {
						$recurring_ids[] = $recurring['recurring_id'];
					}

					if (!in_array($recurring_id, $recurring_ids)) {
						$errors[] = $this->language->get('error_recurring_required');
					}
				}

				$this->cart->add($product['product_id'], $product['quantity'], isset($option[0]) ? $option[0] : $option, $recurring_id);

			}
			if ($this->cart->hasShipping()) {
				$shippingZone = json_decode($this->getShippingZone($order_status['address_details']));
				$order_info['payment_firstname'] = $order_status['client_first_name'];
				$order_info['payment_lastname'] = $order_status['client_last_name'];
				$order_info['payment_company'] = '';
				$order_info['payment_address_1'] = $order_status['address_details']['street1'];
				$order_info['payment_address_2'] = isset($order_status['address_details']['street1']) ? $order_status['address_details']['street1'] : '';
				$order_info['payment_city'] = $order_status['address_details']['city'];
				$order_info['payment_postcode'] = $order_status['address_details']['postcode'];
				$order_info['payment_zone'] = $order_status['address_details']['state'];
				$order_info['payment_zone_id'] = $shippingZone->zone_id;
				$order_info['payment_country'] = $order_status['address_details']['country'];
				$order_info['payment_country_id'] = $shippingZone->country_id;
				$order_info['payment_address_format'] = "{firstname} {lastname}
			{company}
			{address_1}
			{address_2}
			{city}, {zone} {postcode}
			{country}";
			}
			$order_info['payment_method'] = 'Amwal Quick checkout';


			$order_info['payment_code'] = 'amwal';
			$order_info['payment_custom_field'] = array(
				'transaction_id' => $order_status['id']
			);


			if ($this->cart->hasShipping()) {
				$order_info['shipping_firstname'] = $order_status['client_first_name'];
				$order_info['shipping_lastname'] = $order_status['client_last_name'];
				$order_info['shipping_company'] = '';
				$order_info['shipping_address_1'] = $order_status['address_details']['street1'];
				$order_info['shipping_address_2'] = isset($order_status['address_details']['street1']) ? $order_status['address_details']['street1'] : '';
				$order_info['shipping_city'] = $order_status['address_details']['city'];
				$order_info['shipping_postcode'] = $order_status['address_details']['postcode'];
				$order_info['shipping_zone'] = $order_status['address_details']['state'];
				$order_info['shipping_zone_id'] = $shippingZone->zone_id;
				$order_info['shipping_country'] = $order_status['address_details']['country'];
				$order_info['shipping_country_id'] = $shippingZone->country_id;
				$order_info['shipping_address_format'] = "{firstname} {lastname}
				{company}
				{address_1}
				{address_2}
				{city}, {zone} {postcode}
				{country}";


				if (isset($order_status['shipping_details']['label'])) {
					$order_info['shipping_method'] = $order_status['shipping_details']['label'];
				} else {
					$order_info['shipping_method'] = '';
				}

				if (isset($order_status['shipping_details']['id'])) {
					$order_info['shipping_code'] = $order_status['shipping_details']['id'];
				} else {
					$order_info['shipping_code'] = '';
				}
				$this->session->data['shipping_method'] = array(
					'cost' => $order_status['shipping_details']['price'],
					'tax_class_id' => $order_status['shipping_details']['tax_class_id'],
					'code' => $order_status['shipping_details']['id'],
					'title' => $order_status['shipping_details']['label']
				);
			} else {
				$order_info['shipping_firstname'] = '';
				$order_info['shipping_lastname'] = '';
				$order_info['shipping_company'] = '';
				$order_info['shipping_address_1'] = '';
				$order_info['shipping_address_2'] = '';
				$order_info['shipping_city'] = '';
				$order_info['shipping_postcode'] = '';
				$order_info['shipping_zone'] = '';
				$order_info['shipping_zone_id'] = '';
				$order_info['shipping_country'] = '';
				$order_info['shipping_country_id'] = '';
				$order_info['shipping_address_format'] = '';
				$order_info['shipping_custom_field'] = array();
				$order_info['shipping_method'] = '';
				$order_info['shipping_code'] = '';
			}
			$order_info['invoice_prefix'] = $this->config->get('config_invoice_prefix');
			$order_info['store_id'] = $this->config->get('config_store_id');
			$order_info['store_name'] = $this->config->get('config_name');

			if ($order_info['store_id']) {
				$order_info['store_url'] = $this->config->get('config_url');
			} else {
				if ($this->request->server['HTTPS']) {
					$order_info['store_url'] = HTTPS_SERVER;
				} else {
					$order_info['store_url'] = HTTP_SERVER;
				}
			}
			$order_info['products'] = array();

			foreach ($this->cart->getProducts() as $product) {
				$option_data = array();

				foreach ($product['option'] as $option) {
					$option_data[] = array(
						'product_option_id' => $option['product_option_id'],
						'product_option_value_id' => $option['product_option_value_id'],
						'option_id' => $option['option_id'],
						'option_value_id' => $option['option_value_id'],
						'name' => $option['name'],
						'value' => $option['value'],
						'type' => $option['type']
					);
				}

				$order_info['products'][] = array(
					'product_id' => $product['product_id'],
					'name' => $product['name'],
					'model' => $product['model'],
					'option' => $option_data,
					'download' => $product['download'],
					'quantity' => $product['quantity'],
					'subtract' => $product['subtract'],
					'price' => $product['price'],
					'total' => $product['total'],
					'tax' => $this->tax->getTax($product['price'], $product['tax_class_id']),
					'reward' => $product['reward']
				);
			}
			// Gift Voucher
			$order_info['vouchers'] = array();

			if (!empty($this->session->data['vouchers'])) {
				foreach ($this->session->data['vouchers'] as $voucher) {
					$order_info['vouchers'][] = array(
						'description' => $voucher['description'],
						'code' => token(10),
						'to_name' => $voucher['to_name'],
						'to_email' => $voucher['to_email'],
						'from_name' => $voucher['from_name'],
						'from_email' => $voucher['from_email'],
						'voucher_theme_id' => $voucher['voucher_theme_id'],
						'message' => $voucher['message'],
						'amount' => $voucher['amount']
					);
				}
			}

			$order_info['comment'] = (isset($this->session->data['comment']) ? $this->session->data['comment'] : '');

			if (isset($this->request->cookie['tracking'])) {
				$order_info['tracking'] = $this->request->cookie['tracking'];

				$sub_total = $this->cart->getSubTotal();

				// Affiliate
				$this->load->model('account/customer');

				$affiliate_info = $this->model_account_customer->getAffiliateByTracking($this->request->cookie['tracking']);

				if ($affiliate_info) {
					$order_info['affiliate_id'] = $affiliate_info['customer_id'];
					$order_info['commission'] = ($sub_total / 100) * $affiliate_info['commission'];
				} else {
					$order_info['affiliate_id'] = 0;
					$order_info['commission'] = 0;
				}

				// Marketing
				$this->load->model('checkout/marketing');

				$marketing_info = $this->model_checkout_marketing->getMarketingByCode($this->request->cookie['tracking']);

				if ($marketing_info) {
					$order_info['marketing_id'] = $marketing_info['marketing_id'];
				} else {
					$order_info['marketing_id'] = 0;
				}
			} else {
				$order_info['affiliate_id'] = 0;
				$order_info['commission'] = 0;
				$order_info['marketing_id'] = 0;
				$order_info['tracking'] = '';
			}

			$order_info['language_id'] = $this->config->get('config_language_id');
			$order_info['currency_id'] = $this->currency->getId($this->session->data['currency']);
			$order_info['currency_code'] = $this->session->data['currency'];
			$order_info['currency_value'] = $this->currency->getValue($this->session->data['currency']);
			$order_info['ip'] = $this->request->server['REMOTE_ADDR'];

			if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
				$order_info['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
			} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
				$order_info['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
			} else {
				$order_info['forwarded_ip'] = '';
			}

			if (isset($this->request->server['HTTP_USER_AGENT'])) {
				$order_info['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
			} else {
				$order_info['user_agent'] = '';
			}

			if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
				$order_info['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
			} else {
				$order_info['accept_language'] = '';
			}
			$updateOrder['products'] = $this->cart->getProducts();

			$totals = array();
			$taxes = $this->cart->getTaxes();
			$total = 0;

			// Because __call can not keep var references so we put them into an array.
			$total_data = array(
				'totals' => &$totals,
				'taxes' => &$taxes,
				'total' => &$total
			);

			$this->load->model('setting/extension');
			$sort_order = array();

			$results = $this->model_setting_extension->getExtensions('total');

			foreach ($results as $key => $value) {
				$sort_order[$key] = $this->config->get('total_' . $value['code'] . '_sort_order');
			}

			array_multisort($sort_order, SORT_ASC, $results);

			foreach ($results as $result) {
				if ($this->config->get('total_' . $result['code'] . '_status')) {
					$this->load->model('extension/total/' . $result['code']);

					// We have to put the totals in an array so that they pass by reference.
					$this->{'model_extension_total_' . $result['code']}->getTotal($total_data);
				}
			}

			$sort_order = array();

			foreach ($totals as $key => $value) {
				$sort_order[$key] = $value['sort_order'];
			}

			array_multisort($sort_order, SORT_ASC, $totals);

			$updateOrder['totals'] = $totals;
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($updateOrder));
			$this->cart->clear();
		}
	}
}