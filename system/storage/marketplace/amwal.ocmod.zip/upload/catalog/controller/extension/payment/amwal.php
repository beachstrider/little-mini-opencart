<?php

class ControllerExtensionPaymentAmwal extends Controller
{
	private $error = [];

	public function index(): string
	{
		if ($this->config->get('payment_amwal_api_key') && $this->config->get('payment_amwal_currency_code')) {
			$this->load->language('extension/payment/amwal');
			$this->load->model('checkout/order');
			$this->load->model('extension/payment/amwal');
			$this->load->model('localisation/country');
			$this->load->model('checkout/order');

			$country = $this->model_localisation_country->getCountry($this->config->get('config_country_id'));

			// Setting
			$_config = new Config();
			$_config->load('amwal');

			$config_setting = $_config->get('amwal_setting');



			$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('payment_amwal_setting'));
			$data['amwal_api_key_value'] = $this->config->get('payment_amwal_api_key');
			$data['payment_amwal_currency_code'] = $this->config->get('payment_amwal_currency_code');
			$data['amwal_dark_mode_value'] = $this->config->get('payment_amwal_dark_mode_value');
			$data['amwal_address_required_value'] = false;
			$data['amwal_guest_email_required_value'] = false;
			$data['amwal_test_mode_value'] = $this->config->get('payment_amwal_test_mode');
			$data['amwal_debug_mode_value'] = $this->config->get('payment_amwal_debug_mode');
			$data['amwal_button_in_product_page_value'] = $this->config->get('payment_amwal_button_in_product_page');
			$data['amwal_hide_button_if_cart_has_item_value'] = $this->config->get('payment_amwal_hide_button_if_cart_has_item');
			$data['amwal_automaticaly_render_in_cart_page_value'] = $this->config->get('payment_amwal_automaticaly_render_in_cart_page');
			$data['amwal_automaticaly_render_in_mini_cart_value'] = $this->config->get('payment_amwal_automaticaly_render_in_mini_cart');
			$data['order_id'] = $this->session->data['order_id'];
			if (isset($this->session->data['customer']['telephone'])) {
				$data['customer_telephone'] = ($this->session->data['customer']['telephone']);
			}
			if (isset($this->session->data['customer'])) {
				$data['customer_email'] = ($this->session->data['customer']['email']);
			} else {
				$data['customer_email'] = ($this->session->data['guest']['email']);

			}



			$amount_info = $this->getOrderInfo();

			$data['currency_code'] = $this->session->data['currency'];
			$data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
			$data['decimal_place'] = $setting['currency'][$data['currency_code']]['decimal_place'];
			$data['message_amount'] = $amount_info['breakdown']['item_total']['value'];
			$data['taxes'] = $amount_info['breakdown']['tax_total']['value'];
			$data['discount'] = $amount_info['breakdown']['discount']['value'];
			if (isset($amount_info['shippingMethods'])) {
				$data['shippingMethods'] = $amount_info['shippingMethods'];
			}
			$data['lang'] = explode("-", $this->session->data['language'])[0];

			return $this->load->view('extension/payment/amwal', $data);
		}

		return '';
	}
	public function getOrderInfo()
	{
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		$data['lang'] = $this->language->get('code');
		$shipping_info = array();
		if ($this->cart->hasShipping()) {
			$shipping_info['name']['full_name'] = $order_info['shipping_firstname'];
			$shipping_info['name']['full_name'] .= ($order_info['shipping_lastname'] ? (' ' . $order_info['shipping_lastname']) : '');
			$shipping_info['address']['address_line_1'] = $order_info['shipping_address_1'];
			$shipping_info['address']['address_line_2'] = $order_info['shipping_address_2'];
			$shipping_info['address']['admin_area_1'] = $order_info['shipping_zone'];
			$shipping_info['address']['admin_area_2'] = $order_info['shipping_city'];
			$shipping_info['address']['postal_code'] = $order_info['shipping_postcode'];

			if ($order_info['shipping_country_id']) {
				$this->load->model('localisation/country');

				$country_info = $this->model_localisation_country->getCountry($order_info['shipping_country_id']);

				if ($country_info) {
					$shipping_info['address']['country_code'] = $country_info['iso_code_2'];
				}
			}

			$shipping_preference = 'SET_PROVIDED_ADDRESS';
		} else {
			$shipping_preference = 'NO_SHIPPING';
		}

		$item_info = array();
		$item_total = 0;
		$tax_total = 0;
		$currency_value = $this->currency->getValue($this->session->data['currency']);
		$decimal_place = 2;
		$currency_code = $this->session->data['currency'];
		foreach ($this->cart->getProducts() as $product) {
			$product_price = number_format($product['price'] * $currency_value, $decimal_place, '.', '');

			$item_info[] = array(
				'name' => $product['name'],
				'sku' => $product['model'],
				'url' => $this->url->link('product/product', 'product_id=' . $product['product_id'], true),
				'quantity' => $product['quantity'],
				'unit_amount' => array(
					'currency_code' => $currency_code,
					'value' => $product_price
				)
			);

			$item_total += $product_price * $product['quantity'];

			if ($product['tax_class_id']) {
				$tax_rates = $this->tax->getRates($product['price'], $product['tax_class_id']);

				foreach ($tax_rates as $tax_rate) {
					$tax_total += ($tax_rate['amount'] * $product['quantity']);
				}
			}
		}

		$item_total = number_format($item_total, $decimal_place, '.', '');
		$tax_total = number_format($tax_total * $currency_value, $decimal_place, '.', '');

		$discount_total = 0;
		$handling_total = 0;
		$shipping_total = 0;
		if (isset($this->session->data['shipping_method'])) {
			$shipping_total = $this->tax->calculate($this->session->data['shipping_method']['cost'], $this->session->data['shipping_method']['tax_class_id'], true);
			$data['shippingMethods'] = array(
				[
					'price' => $shipping_total,
					'id' => $this->session->data['shipping_method']['code'],
					'label' => $this->session->data['shipping_method']['title'],

				]
			);
			$shipping_total = number_format($shipping_total * $currency_value, $decimal_place, '.', '');
		}

		$order_total = number_format($order_info['total'] * $currency_value, $decimal_place, '.', '');
		$rebate = number_format($item_total + $tax_total + $shipping_total - $order_total, $decimal_place, '.', '');

		if ($rebate > 0) {
			$discount_total = $rebate;
		} elseif ($rebate < 0) {
			$handling_total = -$rebate;
		}

		$amount_info = array(
			'currency_code' => $currency_code,
			'value' => $order_total,
			'shippingMethods' => isset($this->session->data['shipping_method']) ? $data['shippingMethods'] : null,
			'breakdown' => array(
				'item_total' => array(
					'currency_code' => $currency_code,
					'value' => $item_total
				),
				'tax_total' => array(
					'currency_code' => $currency_code,
					'value' => $tax_total
				),
				'shipping' => array(
					'currency_code' => $currency_code,
					'value' => $shipping_total
				),
				'handling' => array(
					'currency_code' => $currency_code,
					'value' => $handling_total
				),
				'discount' => array(
					'currency_code' => $currency_code,
					'value' => $discount_total
				)
			)
		);
		return $amount_info;
	}
	public function approveOrder(): void
	{
		$this->load->language('extension/payment/amwal');

		$this->load->model('extension/payment/amwal');
		$this->load->model('checkout/order');

		// Setting
		$_config = new Config();
		$_config->load('amwal');
		$config_setting = $_config->get('amwal_setting');

		$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('payment_amwal_setting'));
		$amwal_api_key_value = $this->config->get('payment_amwal_api_key');
		$amwal_info = [
			'payment_amwal_api_key' => $amwal_api_key_value
		];
		require_once DIR_SYSTEM . 'library/amwal/amwal.php';

		$amwal = new Amwal($amwal_info);
		if (isset($this->request->post['orderId'])) {
			$order_status = $amwal->checkOrderStatus($this->request->post['orderId']);
			$order_data = [];

			// Totals
			$totals = [];
			$taxes = $this->cart->getTaxes();
			$total = 0;

			$sort_order = [];
			$this->session->data['order_id'] = $order_status['ref_id'];
			$oc_order_info = $this->getOrderInfo();
			$amount = $oc_order_info['breakdown']['item_total']['value'];
			$taxes = $oc_order_info['breakdown']['tax_total']['value'];
			$discount = $oc_order_info['breakdown']['discount']['value'];
			$shippingMethods = isset($oc_order_info['shippingMethods']) ? $oc_order_info['shippingMethods'] : [];
			$total = $oc_order_info['value'];
			if ($order_status['total_amount'] === number_format($total, 2)) {
				$order_data['transaction_id'] = $order_status['id'];
				$order_data['products'] = [];

				foreach ($this->cart->getProducts() as $product) {
					$option_data = [];

					foreach ($product['option'] as $option) {
						$option_data[] = [
							'product_option_id' => $option['product_option_id'],
							'product_option_value_id' => $option['product_option_value_id'],
							'option_id' => $option['option_id'],
							'option_value_id' => $option['option_value_id'],
							'name' => $option['name'],
							'value' => $option['value'],
							'type' => $option['type']
						];
					}

					$order_data['products'][] = [
						'product_id' => $product['product_id'],
						'name' => $product['name'],
						'model' => $product['model'],
						'option' => $option_data,
						'subscription' => $product['recurring'],
						'download' => $product['download'],
						'quantity' => $product['quantity'],
						'subtract' => $product['subtract'],
						'price' => $product['price'],
						'total' => $product['total'],
						'tax' => $this->tax->getTax($product['price'], $product['tax_class_id']),
						'reward' => $product['reward']
					];
				}

				// Gift Voucher
				$order_data['vouchers'] = [];

				if (!empty($this->session->data['vouchers'])) {
					foreach ($this->session->data['vouchers'] as $voucher) {
						$order_data['vouchers'][] = [
							'description' => $voucher['description'],
							'code' => token(10),
							'to_name' => $voucher['to_name'],
							'to_email' => $voucher['to_email'],
							'from_name' => $voucher['from_name'],
							'from_email' => $voucher['from_email'],
							'voucher_theme_id' => $voucher['voucher_theme_id'],
							'message' => $voucher['message'],
							'amount' => $voucher['amount']
						];
					}
				}

				$order_data['comment'] = (isset($this->session->data['comment']) ? $this->session->data['comment'] : '');


				$this->load->model('checkout/order');
				if ($order_status['status'] == 'success') {
					$order_status_id = $setting['order_status']['processing']['id'];
					$transaction_id = $order_data['transaction_id'];
					$updateOrder = $this->model_checkout_order->getOrder($order_status['ref_id']);
					$updateOrder['payment_custom_field'] = array(
						'transaction_id' => $transaction_id
					);
					$updateOrder['customer_group_id'] = 1;
					if (!isset($updateOrder['products'])) {
						$updateOrder['products'] = $order_data['products'];
					}
					$this->model_checkout_order->editOrder($order_status['ref_id'], $updateOrder);
					$this->model_checkout_order->addOrderHistory($order_status['ref_id'], $order_status_id, (isset($this->session->data['comment']) ? $this->session->data['comment'] : ''));
					$data['redirect'] = $this->url->link('checkout/success', '', true);
				} else {
					$order_status_id = $setting['order_status']['failed']['id'];
					$transaction_id = $order_data['transaction_id'];
					$updateOrder = $this->model_checkout_order->getOrder($order_status['ref_id']);
					$updateOrder['customer_group_id'] = 1;
					$updateOrder['payment_custom_field'] = array(
						'transaction_id' => $transaction_id
					);
					if (!isset($updateOrder['products'])) {
						$updateOrder['products'] = $order_data['products'];
					}
					$this->model_checkout_order->editOrder($order_status['ref_id'], $updateOrder);
					$this->model_checkout_order->addOrderHistory($order_status['ref_id'], $order_status_id, (isset($this->session->data['comment']) ? $this->session->data['comment'] : ''));
					$data['redirect'] = $this->url->link('checkout/fail', '', true);
				}
				$order_data['info'] = $oc_order_info;
				$order_details = [
					'order_url' => $data['redirect'],
					'order_position' => 'checkout_page',
					'order_id' => $order_status['ref_id'],
					'plugin_version' => 'opencart_1.12',
					'order_status' => $order_status['status'] == 'success' ? $setting['order_status']['processing']['code'] : $setting['order_status']['failed']['code'],
					'order_content' => json_encode($order_data),
				];

				$amwal->addOrderDetails($order_data['transaction_id'], $order_details);
				$this->response->addHeader('Content-Type: application/json');
				$this->response->setOutput(json_encode($data));
			}
		}

		$data['lang'] = explode("-", $this->session->data['language'])[0];

		$data['error'] = $this->error;

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));
	}

	public function getShippingMethods(): void
	{
		$this->load->model('localisation/country');
		$this->load->model('localisation/zone');
		$this->load->model('extension/total/shipping');
		$this->load->model('extension/module/amwal_smart_button');
		$country_id = (int) $this->model_extension_module_amwal_smart_button->getCountryByCode($this->request->post['country'])['country_id'];
		$zones = $this->model_localisation_zone->getZonesByCountryId($country_id);
		$zone_id = 1;
		if (isset($this->request->post['state_code'])) {
			$zone_id = $this->request->post['state_code'];
		} else {
			$city = str_replace('-', ' ', $this->request->post['city']);
			foreach ($zones as $zoneItem) {
				if (strtolower($zoneItem['name']) == strtolower($city)) {
					$zone_id = (int) $zoneItem['zone_id'];
					break;
				}
			}
		}


		$data['zone_id'] = $zone_id;
		$data['country_id'] = $country_id;
		$data['postcode'] = '';
		$_config = new Config();
		$_config->load('amwal');

		$amwal_setting = $_config->get('amwal_setting');

		$_config = new Config();
		$_config->load('amwal_smart_button');

		$config_setting = $_config->get('amwal_smart_button_setting');

		$setting = array_replace_recursive((array) $config_setting, (array) $this->config->get('module_amwal_smart_button_setting'));

		$this->load->model('checkout/order');
		$order_info = $this->getOrderInfo();
		$data['amount'] = $order_info['breakdown']['item_total']['value'];
		$data['taxes'] = $order_info['breakdown']['tax_total']['value'];
		$data['discount'] = $order_info['breakdown']['discount']['value'];
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));
	}
	public function getShippingMethodsAfterTax(): void
	{
		if (isset($this->request->post['shipping_method'])) {
			$data['shipping_method'] = [];
			foreach ($this->request->post['shipping_method'] as $key => $value) {
				foreach ($value['quote'] as $innerkey => $innervalue) {
					$shipping_total = $this->tax->calculate($value['quote'][$innerkey]['cost'], $value['quote'][$innerkey]['tax_class_id'], true);
					array_push(
						$data['shipping_method'],
						[
							'price' => $shipping_total,
							'inital_price' => $value['quote'][$innerkey]['cost'],
							'id' => $value['quote'][$innerkey]['code'],
							'label' => $value['quote'][$innerkey]['title'],
							'tax_class_id' => $value['quote'][$innerkey]['tax_class_id']

						]
					);
				}
			}
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($data));
		}
	}
}