<?php

namespace Squareup\Exception;

class Image extends \RuntimeException {

}