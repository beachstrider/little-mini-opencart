<?php

namespace vendor\isenselabs\Squareup\Exception;

class Network extends \RuntimeException {

}